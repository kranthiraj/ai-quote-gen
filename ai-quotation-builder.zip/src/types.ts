/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export enum UserRole {
  SUPER_ADMIN = "SUPER_ADMIN",
  STAFF = "STAFF",
  READ_ONLY = "READ_ONLY"
}

export interface RolePermissions {
  createQuotation: boolean;
  editQuotation: boolean;
  deleteQuotation: boolean;
  manageCompanies: boolean;
  manageCustomers: boolean;
  manageItems: boolean;
  aiFeatures: boolean;
  superAdminSettings: boolean;
}

export interface Company {
  id: string;
  name: string;
  logoUrl?: string;
  gstin?: string;
  pan?: string;
  cin?: string;
  address: string;
  state: string;
  country: string;
  mobile: string;
  email: string;
  website?: string;
  bankName?: string;
  accountNumber?: string;
  ifsc?: string;
  branch?: string;
  upiId?: string;
  upiQrCodeUrl?: string; // Base64 or URL
  signatureUrl?: string;  // Base64 or URL
  companySealUrl?: string; // Base64 or URL
  themeColor: string;     // Hex color
  footerNotes?: string;
  isActive: boolean;
}

export interface Customer {
  id: string;
  name: string;
  companyName?: string;
  gstin?: string;
  pan?: string;
  address: string;
  mobile: string;
  email: string;
  state: string;
  country: string;
}

export interface Item {
  id: string;
  name: string;
  description?: string;
  unit: string;
  hsnCode?: string;
  sacCode?: string;
  rate: number;
  taxPercentage: number;
}

export interface QuotationItem {
  itemId?: string;
  name: string;
  description?: string;
  quantity: number;
  unit: string;
  price: number;
  discount: number; // Percentage or absolute flat value (we'll support percentage)
  taxPercentage: number;
  hsnCode?: string;
  sacCode?: string;
  total: number;
}

export interface ExtraCharge {
  id: string;
  name: string;
  amount: number;
  isActive: boolean;
}

export interface Quotation {
  id: string;
  quotationNumber: string;
  quotationDate: string;
  validUntil: string;
  companyId: string;
  customerId: string;
  templateId: string; // Theme/Design layout ID
  items: QuotationItem[];
  extraCharges: ExtraCharge[];
  notes?: string;
  terms?: string;
  status: "Draft" | "Sent" | "Approved" | "Rejected" | "Expired";
  version: number;
  subtotal: number;
  discountTotal: number;
  taxTotal: number;
  chargesTotal: number;
  finalAmount: number;
  isWatermarked: boolean;
  qrVerifiedUrl?: string;
  deliveryDate?: string;
}

export interface QuotationVersion {
  id: string;
  quotationId: string;
  version: number;
  timestamp: string;
  updatedBy: string;
  changes: string;
  data: Quotation;
}

export interface TemplateComponent {
  id: string;
  type: "Logo" | "Text" | "Header" | "Footer" | "Table" | "QR" | "Signature" | "Terms" | "Notes" | "BankDetails";
  title: string;
  isVisible: boolean;
  order: number;
  customStyle?: string;
}

export interface VisualTemplate {
  id: string;
  name: string;
  bgColor: string;     // e.g. "#ffffff" or "dark" theme
  accentColor: string; // primary highlight
  fontFamily: string;
  components: TemplateComponent[];
  isCustom: boolean;   // if created by admin
}

export interface SystemSettings {
  currency: string;             // ₹, $, €, £
  taxDefaultType: "No Tax" | "GST" | "CGST_SGST" | "IGST" | "VAT" | "Custom";
  taxDefaultRate: number;       // default tax percent
  numberFormat: "Indian" | "US" | "European";
  dateFormat: "DD/MM/YYYY" | "YYYY-MM-DD" | "MM/DD/YYYY";
  whatsappMessageTemplate?: string;
  emailMessageTemplate?: string;
  lastBackupDate?: string;
}

export interface AdminControls {
  enableAiFeatures: boolean;
  enableTemplates: boolean;
  enableTaxModule: boolean;
  enableExportModule: boolean;
  enableWhatsApp: boolean;
  enableEmail: boolean;
  enableOCR: boolean;
  enableVoiceInput: boolean;
}

export interface DBStructure {
  companies: Company[];
  customers: Customer[];
  items: Item[];
  quotations: Quotation[];
  quotationVersions: QuotationVersion[];
  visualTemplates: VisualTemplate[];
  settings: SystemSettings;
  adminControls: AdminControls;
  userRole: UserRole;
}
