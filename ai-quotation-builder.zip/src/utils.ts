/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

// Convert numbers into words (Indian numbering system format by default, fallback for general layout)
export function numberToWords(num: number, currencySymbol: string = "₹"): string {
  if (isNaN(num)) return "";
  num = Math.floor(num);
  if (num === 0) return "Zero Rupees Only";

  const a = [
    "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine",
    "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen",
    "Seventeen", "Eighteen", "Nineteen"
  ];
  const b = ["", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"];

  function convertLessThanThousand(n: number): string {
    if (n === 0) return "";
    let str = "";
    if (n >= 100) {
      str += a[Math.floor(n / 100)] + " Hundred ";
      n %= 100;
    }
    if (n > 0) {
      if (str !== "") str += "and ";
      if (n < 20) {
        str += a[n];
      } else {
        str += b[Math.floor(n / 10)];
        if (n % 10 > 0) {
          str += "-" + a[n % 10];
        }
      }
    }
    return str.trim();
  }

  let words = "";
  let temp = num;

  // Crore (1,00,00,000)
  if (temp >= 10000000) {
    const crore = Math.floor(temp / 10000000);
    words += convertLessThanThousand(crore) + " Crore ";
    temp %= 10000000;
  }

  // Lakh (1,00,000)
  if (temp >= 100000) {
    const lakh = Math.floor(temp / 100000);
    words += convertLessThanThousand(lakh) + " Lakh ";
    temp %= 100000;
  }

  // Thousand (1,000)
  if (temp >= 1000) {
    const thousand = Math.floor(temp / 1000);
    words += convertLessThanThousand(thousand) + " Thousand ";
    temp %= 1000;
  }

  // Remainder
  if (temp > 0) {
    words += convertLessThanThousand(temp);
  }

  const currencyName = currencySymbol === "₹" ? "Rupees" : currencySymbol === "$" ? "Dollars" : currencySymbol === "€" ? "Euros" : "Pounds";
  return `${words.trim()} ${currencyName} Only`;
}

// Localized format patterns
export function formatCurrency(amount: number, currency: string = "₹", format: "Indian" | "US" | "European" = "Indian"): string {
  if (isNaN(amount)) return `${currency}0.00`;
  
  if (format === "Indian") {
    // Custom regex based lakhs formatting
    const x = amount.toFixed(2).split(".");
    let x1 = x[0];
    const x2 = x.length > 1 ? "." + x[1] : "";
    const rgx = /(\d+)(\d{3})/;
    if (x1.length > 3) {
      const lastThree = x1.substring(x1.length - 3);
      const otherNumbers = x1.substring(0, x1.length - 3);
      x1 = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + "," + lastThree;
    }
    return `${currency}${x1}${x2}`;
  } else if (format === "European") {
    return `${currency}${amount.toFixed(2).replace(".", ",").replace(/\B(?=(\d{3})+(?!\d))/g, ".")}`;
  } else {
    // US Format
    return `${currency}${amount.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ",")}`;
  }
}
