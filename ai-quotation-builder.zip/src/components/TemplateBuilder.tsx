/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from "react";
import { MoveUp, MoveDown, Eye, EyeOff, LayoutTemplate, Palette, Type, AlertCircle, Sparkles, Plus, Loader2 } from "lucide-react";
import { VisualTemplate, TemplateComponent } from "../types";

interface TemplateBuilderProps {
  templates: VisualTemplate[];
  onAddTemplate: (t: Omit<VisualTemplate, "id" | "isCustom">) => void;
  onUpdateTemplate: (id: string, t: Partial<VisualTemplate>) => void;
}

export default function TemplateBuilder({ templates, onAddTemplate, onUpdateTemplate }: TemplateBuilderProps) {
  const [selectedId, setSelectedId] = useState<string>("tmpl-1");
  const [isAiStyling, setIsAiStyling] = useState(false);
  const [aiPrompt, setAiPrompt] = useState("");
  const [newTemplateName, setNewTemplateName] = useState("");

  const activeTemplate = useMemo(() => {
    return templates.find(t => t.id === selectedId) || templates[0];
  }, [templates, selectedId]);

  // Fallback default components if template's component list is empty
  const defaultComponents: TemplateComponent[] = [
    { id: "logo", type: "Logo", title: "Corporate Logo Banner", isVisible: true, order: 0 },
    { id: "header", type: "Header", title: "Quotation Meta-Headers", isVisible: true, order: 1 },
    { id: "text", type: "Text", title: "Corporate Address Cards", isVisible: true, order: 2 },
    { id: "table", type: "Table", title: "Interactive Invoice Table", isVisible: true, order: 3 },
    { id: "bank", type: "BankDetails", title: "Bank Clearance details", isVisible: true, order: 4 },
    { id: "terms", type: "Terms", title: "Contract Terms & Conditions", isVisible: true, order: 5 },
    { id: "notes", type: "Notes", title: "Appreciation Note Details", isVisible: true, order: 6 },
    { id: "qr", type: "QR", title: "Verification QR Stamp", isVisible: true, order: 7 },
    { id: "signature", type: "Signature", title: "Official Stamp & Signature", isVisible: true, order: 8 },
    { id: "footer", type: "Footer", title: "Corporate Copyright Footer", isVisible: true, order: 9 }
  ];

  const templateComponents = useMemo(() => {
    if (!activeTemplate) return [];
    if (!activeTemplate.components || activeTemplate.components.length === 0) {
      return defaultComponents;
    }
    return [...activeTemplate.components].sort((a, b) => a.order - b.order);
  }, [activeTemplate]);

  // Adjust order
  const handleMoveComponent = (index: number, direction: "up" | "down") => {
    if (!activeTemplate) return;
    const items = [...templateComponents];
    const targetIdx = direction === "up" ? index - 1 : index + 1;
    if (targetIdx < 0 || targetIdx >= items.length) return;

    // Swap ordering parameters
    const temp = items[index].order;
    items[index].order = items[targetIdx].order;
    items[targetIdx].order = temp;

    onUpdateTemplate(activeTemplate.id, { components: items });
  };

  // Toggle Visibility
  const handleToggleVisible = (comp: TemplateComponent) => {
    if (!activeTemplate) return;
    const items = templateComponents.map(item =>
      item.id === comp.id ? { ...item, isVisible: !item.isVisible } : item
    );
    onUpdateTemplate(activeTemplate.id, { components: items });
  };

  // Trigger Gemini AI styling editor route
  const handleAiEditStyle = async () => {
    if (!aiPrompt) return;
    try {
      setIsAiStyling(true);
      const res = await fetch("/api/ai/template-editor", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt: aiPrompt,
          currentTemplate: {
            bgColor: activeTemplate.bgColor,
            accentColor: activeTemplate.accentColor,
            fontFamily: activeTemplate.fontFamily
          }
        })
      });
      const data = await res.json();
      if (data.error) {
        alert(data.error);
        return;
      }
      onUpdateTemplate(activeTemplate.id, {
        bgColor: data.bgColor,
        accentColor: data.accentColor,
        fontFamily: data.fontFamily
      });
      setAiPrompt("");
      alert(`AI updated style settings! Font: ${data.fontFamily}, Bg: ${data.bgColor}, Accent: ${data.accentColor}`);
    } catch (err: any) {
      alert("Failed styling template via Gemini API: " + err.message);
    } finally {
      setIsAiStyling(false);
    }
  };

  // Create new blank visual layout
  const handleCreateNewTemplate = () => {
    if (!newTemplateName) return;
    onAddTemplate({
      name: newTemplateName,
      bgColor: "#ffffff",
      accentColor: "#6366f1",
      fontFamily: "Inter",
      components: defaultComponents
    });
    setNewTemplateName("");
    alert("New custom template successfully created!");
  };

  return (
    <div className="space-y-6">
      {/* Visual Workspace banner */}
      <div className="bg-gradient-to-r from-violet-600 to-indigo-700 text-white p-6 rounded-2xl shadow-xs">
        <h2 className="text-xl font-bold flex items-center gap-2"><LayoutTemplate className="w-5 h-5" /> Visual Visual Template Builder (Drag/Sort components)</h2>
        <p className="text-indigo-100 text-xs mt-1.5 max-w-2xl leading-relaxed">
          Reorder template segments, manage element visibilities, and apply personalized dynamic themes instantly. Custom modifications automatically apply to newly saved quotation sheets.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Sidebar Selector */}
        <div className="col-span-12 lg:col-span-4 space-y-4">
          <div className="bg-white border border-slate-100 rounded-xl shadow-xs p-5 space-y-4 text-sm">
            <h3 className="font-semibold text-slate-800 flex items-center gap-1.5">
              <palette className="w-4 h-4 text-theme" /> Template Catalog List
            </h3>
            <div className="space-y-1.5 max-h-60 overflow-y-auto">
              {templates.map((t) => (
                <button
                  key={t.id}
                  onClick={() => setSelectedId(t.id)}
                  className={`w-full text-left p-3 rounded-lg border flex items-center justify-between text-xs transition-colors cursor-pointer ${
                    t.id === selectedId
                      ? "bg-slate-900 text-white border-slate-900"
                      : "bg-slate-50 border-slate-150 hover:bg-slate-100 text-slate-700"
                  }`}
                >
                  <span className="font-medium">{t.name}</span>
                  {t.isCustom && <span className="text-[9px] bg-indigo-500 text-white px-1.5 py-0.5 rounded font-mono uppercase">Custom</span>}
                </button>
              ))}
            </div>

            {/* Create Custom form */}
            <div className="pt-4 border-t border-slate-100 space-y-2.5">
              <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wide">Write Custom Template</label>
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="Premium Blue Soft"
                  value={newTemplateName}
                  onChange={(e) => setNewTemplateName(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-1.5 text-xs focus:outline-none"
                />
                <button
                  onClick={handleCreateNewTemplate}
                  className="bg-slate-900 border border-slate-900 text-white px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer shrink-0"
                >
                  Create
                </button>
              </div>
            </div>
          </div>

          {/* AI Theme styling sidebar helper */}
          <div className="bg-slate-900 text-white p-5 rounded-xl space-y-4 text-sm shadow-md border border-slate-800">
            <div className="flex items-center gap-1.5 pb-2 border-b border-slate-800">
              <Sparkles className="w-5 h-5 text-indigo-400" />
              <h4 className="font-semibold text-xs uppercase tracking-wider">AI Template Styler (Gemini Integration)</h4>
            </div>
            <p className="text-xs text-slate-400">
              Instruct Gemini to color or format this template. The AI updates font pairings and background gradients instantly.
            </p>
            <div className="space-y-3">
              <input
                type="text"
                placeholder='e.g. "make template green and premium"'
                value={aiPrompt}
                onChange={(e) => setAiPrompt(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 text-indigo-200 placeholder-slate-600 rounded-lg px-3 py-2 text-xs focus:outline-none"
              />
              <button
                onClick={handleAiEditStyle}
                disabled={isAiStyling || !aiPrompt}
                className="w-full bg-cyan-500 hover:bg-cyan-600 text-slate-950 font-bold px-4 py-2 rounded-lg text-xs flex justify-center items-center gap-1.5 transition-colors cursor-pointer disabled:opacity-50"
              >
                {isAiStyling ? (
                  <>
                    <Loader2 className="w-3.5 h-3.5 animate-spin" /> Styling Template...
                  </>
                ) : (
                  <>Auto-Style Layout</>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Builder Workstation layout controller */}
        <div className="col-span-12 lg:col-span-8 bg-white border border-slate-100 rounded-xl shadow-xs p-4 sm:p-6 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-100 gap-4">
            <div>
              <h3 className="font-semibold text-slate-900 text-base">Layout Workstation: {activeTemplate?.name}</h3>
              <p className="text-xs text-slate-500 mt-1">Structure visual blocks and customize theme variables below.</p>
            </div>
            <div className="flex items-center gap-3">
              {/* Palette view */}
              <div className="flex items-center gap-1 bg-slate-50 px-2.5 py-1.5 rounded-lg border border-slate-100">
                <span className="w-3 h-3 rounded-full border border-slate-200" style={{ backgroundColor: activeTemplate?.accentColor }} />
                <span className="text-xs font-semibold text-slate-600">{activeTemplate?.accentColor}</span>
              </div>
            </div>
          </div>

          {/* Quick theme parameters form */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 p-4 bg-slate-50 rounded-xl border border-slate-120 text-xs">
            <div>
              <label className="block text-slate-500 font-semibold mb-1">Highlight Colors</label>
              <div className="flex items-center gap-2">
                <input
                  type="color"
                  value={activeTemplate?.accentColor || "#1e3a8a"}
                  onChange={(e) => onUpdateTemplate(activeTemplate.id, { accentColor: e.target.value })}
                  className="w-8 h-8 rounded border p-0 cursor-pointer shrink-0"
                />
                <input
                  type="text"
                  value={activeTemplate?.accentColor || ""}
                  onChange={(e) => onUpdateTemplate(activeTemplate.id, { accentColor: e.target.value })}
                  className="w-full bg-white border border-slate-200 rounded px-2 py-1 focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-slate-500 font-semibold mb-1">Background tone</label>
              <div className="flex items-center gap-2">
                <input
                  type="color"
                  value={activeTemplate?.bgColor || "#ffffff"}
                  onChange={(e) => onUpdateTemplate(activeTemplate.id, { bgColor: e.target.value })}
                  className="w-8 h-8 rounded border p-0 cursor-pointer shrink-0"
                />
                <input
                  type="text"
                  value={activeTemplate?.bgColor || ""}
                  onChange={(e) => onUpdateTemplate(activeTemplate.id, { bgColor: e.target.value })}
                  className="w-full bg-white border border-slate-200 rounded px-2 py-1 focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-slate-500 font-semibold mb-1">Font family pairing</label>
              <select
                value={activeTemplate?.fontFamily || "Inter"}
                onChange={(e) => onUpdateTemplate(activeTemplate.id, { fontFamily: e.target.value })}
                className="w-full bg-white border border-slate-200 rounded px-2 py-2"
              >
                <option value="Inter">Inter (Sans)</option>
                <option value="JetBrains Mono">JetBrains Mono (Technical)</option>
                <option value="Playfair Display">Playfair Display (Premium Series)</option>
              </select>
            </div>
          </div>

          {/* Table Reordering Simulator */}
          <div className="space-y-2.5">
            <h4 className="font-semibold text-slate-800 text-xs uppercase tracking-wider">Visual Order & Section Visibility</h4>
            <div className="border border-slate-100 rounded-xl overflow-hidden divide-y divide-slate-100 text-sm">
              {templateComponents.map((comp, idx) => (
                <div key={comp.id} className="p-3.5 flex items-center justify-between gap-4 bg-slate-50/10 hover:bg-slate-50/50 transition-colors">
                  <div className="flex items-center gap-3">
                    <span className="w-5 h-5 bg-slate-100 text-slate-500 font-mono text-[10px] font-bold rounded flex items-center justify-center">
                      {idx + 1}
                    </span>
                    <div>
                      <span className="font-semibold text-slate-800 text-xs">{comp.type}</span>
                      <span className="text-[10px] text-slate-400 block font-normal">{comp.title}</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-4">
                    {/* Toggle button */}
                    <button
                      onClick={() => handleToggleVisible(comp)}
                      className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-semibold tracking-wider uppercase border cursor-pointer ${
                        comp.isVisible
                          ? "bg-emerald-50 text-emerald-700 border-emerald-100"
                          : "bg-slate-50 text-slate-400 border-slate-100"
                      }`}
                    >
                      {comp.isVisible ? (
                        <>
                          <Eye className="w-3.5 h-3.5" /> Visible
                        </>
                      ) : (
                        <>
                          <EyeOff className="w-3.5 h-3.5" /> Hidden
                        </>
                      )}
                    </button>

                    {/* Move elements buttons */}
                    <div className="flex items-center gap-1 border-l border-slate-150 pl-4">
                      <button
                        onClick={() => handleMoveComponent(idx, "up")}
                        disabled={idx === 0}
                        className="p-1 px-1.5 bg-slate-100 hover:bg-slate-200 text-slate-600 disabled:opacity-30 rounded cursor-pointer"
                        title="Move Section Up"
                      >
                        <MoveUp className="w-3 h-3" />
                      </button>
                      <button
                        onClick={() => handleMoveComponent(idx, "down")}
                        disabled={idx === templateComponents.length - 1}
                        className="p-1 px-1.5 bg-slate-100 hover:bg-slate-200 text-slate-600 disabled:opacity-30 rounded cursor-pointer"
                        title="Move Section Down"
                      >
                        <MoveDown className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
