/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from "react";
import { Search, Plus, Trash2, Edit, Copy, Check, EyeOff, CheckCircle, ShieldAlert } from "lucide-react";
import { Company } from "../types";

interface CompanyManagerProps {
  companies: Company[];
  onAddCompany: (c: Omit<Company, "id">) => void;
  onEditCompany: (id: string, c: Partial<Company>) => void;
  onDeleteCompany: (id: string) => void;
  onCloneCompany: (id: string) => void;
}

export default function CompanyManager({ companies, onAddCompany, onEditCompany, onDeleteCompany, onCloneCompany }: CompanyManagerProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [editingId, setEditingId] = useState<string | null>(null);
  const [isCreating, setIsCreating] = useState(false);

  // Form State
  const initialForm: Omit<Company, "id" | "isActive"> = {
    name: "",
    logoUrl: "",
    gstin: "",
    pan: "",
    cin: "",
    address: "",
    state: "Maharashtra",
    country: "India",
    mobile: "",
    email: "",
    website: "",
    bankName: "",
    accountNumber: "",
    ifsc: "",
    branch: "",
    upiId: "",
    upiQrCodeUrl: "",
    signatureUrl: "",
    companySealUrl: "",
    themeColor: "#2563eb",
    footerNotes: ""
  };

  const [form, setForm] = useState(initialForm);

  // Filtering
  const filteredCompanies = useMemo(() => {
    return companies.filter(c =>
      c.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (c.gstin && c.gstin.toLowerCase().includes(searchTerm.toLowerCase())) ||
      c.email.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [companies, searchTerm]);

  const handleOpenEdit = (c: Company) => {
    setEditingId(c.id);
    setForm({
      name: c.name || "",
      logoUrl: c.logoUrl || "",
      gstin: c.gstin || "",
      pan: c.pan || "",
      cin: c.cin || "",
      address: c.address || "",
      state: c.state || "",
      country: c.country || "",
      mobile: c.mobile || "",
      email: c.email || "",
      website: c.website || "",
      bankName: c.bankName || "",
      accountNumber: c.accountNumber || "",
      ifsc: c.ifsc || "",
      branch: c.branch || "",
      upiId: c.upiId || "",
      upiQrCodeUrl: c.upiQrCodeUrl || "",
      signatureUrl: c.signatureUrl || "",
      companySealUrl: c.companySealUrl || "",
      themeColor: c.themeColor || "#2563eb",
      footerNotes: c.footerNotes || ""
    });
    setIsCreating(false);
  };

  const handleOpenCreate = () => {
    setEditingId(null);
    setForm(initialForm);
    setIsCreating(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.email || !form.address) {
      alert("Name, Email and Address are required!");
      return;
    }

    if (editingId) {
      onEditCompany(editingId, form);
      setEditingId(null);
    } else {
      onAddCompany(form);
      setIsCreating(false);
    }
    setForm(initialForm);
  };

  return (
    <div className="space-y-6">
      {/* Search Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white p-5 rounded-xl border border-slate-100 shadow-xs">
        <div className="relative w-full sm:w-80">
          <Search className="w-5 h-5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search company or GSTIN..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-slate-50 border border-slate-200 rounded-lg pl-10 pr-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>
        <button
          onClick={handleOpenCreate}
          className="flex items-center gap-2 bg-slate-900 text-white font-medium hover:bg-slate-800 active:scale-95 px-4 py-2.5 rounded-lg text-sm transition-transform cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          Add New Company
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Panel Listing */}
        <div className={`col-span-12 ${isCreating || editingId ? "lg:col-span-6" : "lg:col-span-12"} space-y-4`}>
          <div className="bg-white rounded-xl border border-slate-100 shadow-xs divide-y divide-slate-100 overflow-hidden">
            {filteredCompanies.length === 0 ? (
              <div className="text-center py-12 text-sm text-slate-400 font-medium">
                No matching active or inactive company listings found.
              </div>
            ) : (
              filteredCompanies.map((c) => (
                <div key={c.id} className="p-4 flex flex-col sm:flex-row items-stretch sm:items-start justify-between gap-4 hover:bg-slate-50/50 transition-colors">
                  <div className="flex gap-4">
                    {c.logoUrl ? (
                      <img src={c.logoUrl} alt="Logo" className="w-12 h-12 rounded-lg bg-slate-100 object-cover border border-slate-200 shrink-0" referrerPolicy="no-referrer" />
                    ) : (
                      <div className="w-12 h-12 bg-indigo-50 text-indigo-600 rounded-lg flex items-center justify-center font-bold text-lg border border-indigo-200 shrink-0">
                        {c.name.slice(0, 2).toUpperCase()}
                      </div>
                    )}
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="font-semibold text-slate-900 text-sm">{c.name}</h4>
                        <span
                          className={`w-2 h-2 rounded-full cursor-pointer ${c.isActive ? "bg-emerald-500" : "bg-slate-300"}`}
                          title={c.isActive ? "Active (Click to Toggle)" : "Inactive (Click to Toggle)"}
                          onClick={() => onEditCompany(c.id, { isActive: !c.isActive })}
                        />
                      </div>
                      <p className="text-xs text-slate-500 mt-0.5">{c.address}</p>
                      <div className="flex flex-wrap items-center gap-x-4 gap-y-1 mt-2 text-xs text-slate-400">
                        {c.gstin && <span><strong>GSTIN:</strong> {c.gstin}</span>}
                        {c.pan && <span><strong>PAN:</strong> {c.pan}</span>}
                        <span>{c.email}</span>
                      </div>
                      {/* Theme Indicator */}
                      <div className="flex items-center gap-1.5 mt-2.5">
                        <span className="w-3.5 h-3.5 rounded-full border border-slate-200" style={{ backgroundColor: c.themeColor }} />
                        <span className="text-[10px] text-slate-400 uppercase tracking-widest font-mono">Accent color: {c.themeColor}</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5 self-end sm:self-center shrink-0 border-t sm:border-t-0 border-slate-100/80 pt-2 sm:pt-0 justify-end w-full sm:w-auto">
                    <button
                      onClick={() => handleOpenEdit(c)}
                      className="p-2 text-slate-500 hover:text-slate-900 hover:bg-slate-50 rounded-lg transition-colors cursor-pointer"
                      title="Edit Company Details"
                    >
                      <Edit className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => onCloneCompany(c.id)}
                      className="p-2 text-slate-500 hover:text-indigo-600 hover:bg-slate-50 rounded-lg transition-colors cursor-pointer"
                      title="Clone/Duplicate Company Setup"
                    >
                      <Copy className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => {
                        if (confirm(`Are you sure you want to delete ${c.name}?`)) onDeleteCompany(c.id);
                      }}
                      className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                      title="Delete profile"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Creation or editing side block */}
        {(isCreating || editingId) && (
          <div className="col-span-12 lg:col-span-6 bg-white border border-slate-100 rounded-xl shadow-xs p-6 space-y-6">
            <div className="flex justify-between items-center pb-3 border-b border-slate-100">
              <h3 className="font-semibold text-slate-900 text-sm">
                {editingId ? "Edit Company Credentials" : "Create New Corporate Entity"}
              </h3>
              <button
                onClick={() => { setEditingId(null); setIsCreating(false); }}
                className="text-xs text-slate-400 hover:text-slate-600 font-medium cursor-pointer"
              >
                Cancel
              </button>
            </div>

            <form onSubmit={handleSave} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="col-span-2">
                  <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">Company Name *</label>
                  <input
                    type="text"
                    required
                    value={form.name}
                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    placeholder="e.g. Acme Corp"
                  />
                </div>

                <div className="col-span-2">
                  <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">Company Logo Link/URL</label>
                  <input
                    type="text"
                    value={form.logoUrl}
                    onChange={(e) => setForm({ ...form, logoUrl: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    placeholder="e.g. https://domain.com/logo.png"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">GSTIN / Tax ID</label>
                  <input
                    type="text"
                    value={form.gstin}
                    onChange={(e) => setForm({ ...form, gstin: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    placeholder="27AAAAA1111A1Z1"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">PAN Number</label>
                  <input
                    type="text"
                    value={form.pan}
                    onChange={(e) => setForm({ ...form, pan: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    placeholder="AAAAA1111A"
                  />
                </div>

                <div className="col-span-2">
                  <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">CIN (Corporate ID Number)</label>
                  <input
                    type="text"
                    value={form.cin}
                    onChange={(e) => setForm({ ...form, cin: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    placeholder="L01234MH2026PLC111222"
                  />
                </div>

                <div className="col-span-2">
                  <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">Address *</label>
                  <textarea
                    required
                    value={form.address}
                    onChange={(e) => setForm({ ...form, address: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-sm h-16 resize-none focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    placeholder="Complete corporate office location address"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">State</label>
                  <input
                    type="text"
                    value={form.state}
                    onChange={(e) => setForm({ ...form, state: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">Country</label>
                  <input
                    type="text"
                    value={form.country}
                    onChange={(e) => setForm({ ...form, country: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">Mobile Contact *</label>
                  <input
                    type="text"
                    value={form.mobile}
                    onChange={(e) => setForm({ ...form, mobile: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">Email Address *</label>
                  <input
                    type="email"
                    required
                    value={form.email}
                    onChange={(e) => setForm({ ...form, email: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>

                <div className="col-span-2">
                  <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">Website Domain</label>
                  <input
                    type="text"
                    value={form.website}
                    onChange={(e) => setForm({ ...form, website: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    placeholder="www.companyname.com"
                  />
                </div>

                {/* Bank Fields heading */}
                <div className="col-span-2 pt-2 border-t border-slate-100">
                  <h5 className="font-semibold text-slate-700 text-xs uppercase tracking-wide">Bank & Clearance Details</h5>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">Bank Name</label>
                  <input
                    type="text"
                    value={form.bankName}
                    onChange={(e) => setForm({ ...form, bankName: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    placeholder="e.g. HDFC Bank"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">Account Number</label>
                  <input
                    type="text"
                    value={form.accountNumber}
                    onChange={(e) => setForm({ ...form, accountNumber: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">IFSC Code</label>
                  <input
                    type="text"
                    value={form.ifsc}
                    onChange={(e) => setForm({ ...form, ifsc: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    placeholder="HDFC0000104"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">UPI ID</label>
                  <input
                    type="text"
                    value={form.upiId}
                    onChange={(e) => setForm({ ...form, upiId: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>

                {/* Theme Customization */}
                <div className="col-span-2 pt-2 border-t border-slate-100">
                  <h5 className="font-semibold text-slate-700 text-xs uppercase tracking-wide">Brand Guidelines</h5>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">Theme Palette Color</label>
                  <div className="flex items-center gap-3">
                    <input
                      type="color"
                      value={form.themeColor}
                      onChange={(e) => setForm({ ...form, themeColor: e.target.value })}
                      className="w-10 h-10 border border-slate-200 p-0.5 rounded cursor-pointer shrink-0"
                    />
                    <input
                      type="text"
                      value={form.themeColor}
                      onChange={(e) => setForm({ ...form, themeColor: e.target.value })}
                      className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>
                </div>

                <div className="col-span-2">
                  <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">Footer Notes (Default)</label>
                  <input
                    type="text"
                    value={form.footerNotes}
                    onChange={(e) => setForm({ ...form, footerNotes: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    placeholder="e.g. Terms accept clearance 10 days"
                  />
                </div>
              </div>

              <div className="flex gap-3 justify-end pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => { setEditingId(null); setIsCreating(false); }}
                  className="bg-slate-100 text-slate-600 px-4 py-2 rounded-lg text-xs font-semibold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-slate-900 text-white hover:bg-slate-800 active:scale-95 px-5 py-2 rounded-lg text-xs font-semibold transition-transform cursor-pointer"
                >
                  {editingId ? "Apply Changes" : "Create Profile"}
                </button>
              </div>
            </form>
          </div>
        )}
      </div>
    </div>
  );
}
