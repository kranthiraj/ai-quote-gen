/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useMemo } from "react";
import { AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend, PieChart, Pie, Cell } from "recharts";
import { FileText, TrendingUp, CheckCircle, Clock, Ban, AlertTriangle, IndianRupee, Users, Building, Plus } from "lucide-react";
import { Company, Customer, Quotation } from "../types";
import { formatCurrency } from "../utils";

interface DashboardProps {
  quotations: Quotation[];
  companies: Company[];
  customers: Customer[];
  onNavigate: (tab: string, arg?: string) => void;
  currency: string;
}

export default function DashboardView({ quotations, companies, customers, onNavigate, currency }: DashboardProps) {
  // Calculations
  const stats = useMemo(() => {
    const total = quotations.length;
    const draft = quotations.filter(q => q.status === "Draft").length;
    const sent = quotations.filter(q => q.status === "Sent").length;
    const approved = quotations.filter(q => q.status === "Approved").length;
    const rejected = quotations.filter(q => q.status === "Rejected").length;
    const expired = quotations.filter(q => q.status === "Expired").length;

    // Approved or sent represents actual business volume tracking
    const totalRevenue = quotations
      .filter(q => q.status === "Approved")
      .reduce((sum, q) => sum + (q.finalAmount || 0), 0);

    return { total, draft, sent, approved, rejected, expired, totalRevenue };
  }, [quotations]);

  // Transform recent data
  const recentQuotations = useMemo(() => {
    return [...quotations]
      .sort((a, b) => new Date(b.quotationDate).getTime() - new Date(a.quotationDate).getTime())
      .slice(0, 5);
  }, [quotations]);

  // Aggregate monthly stats
  const monthlyData = useMemo(() => {
    const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    const counts: { [key: string]: { revenue: number, approved: number, total: number } } = {};
    
    months.forEach(m => {
      counts[m] = { revenue: 0, approved: 0, total: 0 };
    });

    quotations.forEach(q => {
      try {
        const date = new Date(q.quotationDate);
        const m = months[date.getMonth()];
        if (m) {
          counts[m].total += 1;
          if (q.status === "Approved") {
            counts[m].approved += 1;
            counts[m].revenue += q.finalAmount || 0;
          }
        }
      } catch (e) {
        // Safe skip invalid dates
      }
    });

    return months.map(m => ({
      name: m,
      Revenue: counts[m].revenue,
      Approved: counts[m].approved,
      Created: counts[m].total
    }));
  }, [quotations]);

  // Top Customers aggregation
  const topCustomersData = useMemo(() => {
    const custMap: { [key: string]: number } = {};
    quotations.forEach(q => {
      if (q.status === "Approved") {
        custMap[q.customerId] = (custMap[q.customerId] || 0) + q.finalAmount;
      }
    });

    return Object.entries(custMap)
      .map(([id, val]) => {
        const custName = customers.find(c => c.id === id)?.name || "Unknown Customer";
        return { name: custName, Value: val };
      })
      .sort((a, b) => b.Value - a.Value)
      .slice(0, 5);
  }, [quotations, customers]);

  // Top Companies aggregation
  const topCompaniesData = useMemo(() => {
    const compMap: { [key: string]: number } = {};
    quotations.forEach(q => {
      if (q.status === "Approved") {
        compMap[q.companyId] = (compMap[q.companyId] || 0) + (q.finalAmount || 0);
      }
    });

    return Object.entries(compMap)
      .map(([id, val]) => {
        const comp = companies.find(c => c.id === id);
        return { name: comp?.name || "Unknown", Value: val, color: comp?.themeColor || "#3b82f6" };
      })
      .sort((a, b) => b.Value - a.Value)
      .slice(0, 5);
  }, [quotations, companies]);

  const COLORS = ["#10b981", "#3b82f6", "#f59e0b", "#ef4444", "#6b7280"];

  return (
    <div className="space-y-6" id="dashboard-container">
      {/* Welcome Banner */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center bg-slate-900 text-white p-6 rounded-2xl shadow-sm gap-4">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Quotation Dashboard</h1>
          <p className="text-slate-400 text-sm mt-1">
            Build, edit, share visual quotations, and track project pipelines with AI assistance.
          </p>
        </div>
        <button
          onClick={() => onNavigate("builder")}
          className="flex items-center gap-2 bg-emerald-500 hover:bg-emerald-600 active:scale-95 text-slate-950 font-medium px-4 py-2.5 rounded-lg transition-transform cursor-pointer"
          id="btn-create-quote"
        >
          <Plus className="w-4 h-4" />
          Create Quotation
        </button>
      </div>

      {/* Grid Statistics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Rev */}
        <div className="bg-white p-5 rounded-xl border border-slate-100 shadow-xs flex items-center gap-4">
          <div className="bg-emerald-50 p-3 rounded-lg text-emerald-600">
            <TrendingUp className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs text-slate-500 font-medium uppercase tracking-wider">Approved Revenue</p>
            <p className="text-xl font-bold text-slate-900 mt-1">{formatCurrency(stats.totalRevenue, currency)}</p>
          </div>
        </div>

        {/* Total Quotes */}
        <div className="bg-white p-5 rounded-xl border border-slate-100 shadow-xs flex items-center gap-4">
          <div className="bg-blue-50 p-3 rounded-lg text-blue-600">
            <FileText className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs text-slate-500 font-medium uppercase tracking-wider">Total Quotations</p>
            <p className="text-xl font-bold text-slate-900 mt-1">{stats.total} Quotes</p>
          </div>
        </div>

        {/* Approved Quotes */}
        <div className="bg-white p-5 rounded-xl border border-slate-100 shadow-xs flex items-center gap-4">
          <div className="bg-emerald-50 p-3 rounded-lg text-emerald-700">
            <CheckCircle className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs text-slate-500 font-medium uppercase tracking-wider">Approved Quotes</p>
            <p className="text-xl font-bold text-slate-900 mt-1">{stats.approved} Approved</p>
          </div>
        </div>

        {/* Pending Sent */}
        <div className="bg-white p-5 rounded-xl border border-slate-100 shadow-xs flex items-center gap-4">
          <div className="bg-amber-50 p-3 rounded-lg text-amber-600">
            <Clock className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs text-slate-500 font-medium uppercase tracking-wider">Sent (Awaiting)</p>
            <p className="text-xl font-bold text-slate-900 mt-1">{stats.sent} Sent</p>
          </div>
        </div>
      </div>

      {/* Mini status counts */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-50 p-3 rounded-xl border border-slate-100 divide-y divide-slate-200/60 sm:divide-y-0 sm:divide-x">
        <div className="text-center p-2">
          <span className="block text-sm font-semibold text-slate-700">{stats.draft}</span>
          <span className="text-xs text-slate-500">Drafts</span>
        </div>
        <div className="text-center p-2 pt-3 sm:pt-2">
          <span className="block text-sm font-semibold text-rose-600">{stats.rejected}</span>
          <span className="text-xs text-slate-500">Rejected</span>
        </div>
        <div className="text-center p-2 pt-3 sm:pt-2">
          <span className="block text-sm font-semibold text-slate-700">{stats.expired}</span>
          <span className="text-xs text-slate-500">Expired</span>
        </div>
        <div className="text-center p-2 pt-3 sm:pt-2">
          <span className="block text-sm font-semibold text-slate-800">
            {companies.filter(c => c.isActive).length} / {companies.length}
          </span>
          <span className="text-xs text-slate-500">Active Companies</span>
        </div>
      </div>

      {/* Analytics Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Monthly Revenue Chart */}
        <div className="bg-white p-5 rounded-xl border border-slate-100 shadow-xs lg:col-span-8 space-y-4">
          <div className="flex justify-between items-center pb-2 border-b border-slate-100">
            <h3 className="font-semibold text-slate-800 text-sm">Monthly Approved Revenue Pipeline</h3>
            <span className="text-xs bg-emerald-50 text-emerald-700 px-2.5 py-1 rounded-full font-medium">Business Volume</span>
          </div>
          <div className="h-64 rounded-lg">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={monthlyData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.2}/>
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" stroke="#94a3b8" fontSize={11} tickLine={false} />
                <YAxis stroke="#94a3b8" fontSize={11} tickLine={false} />
                <Tooltip 
                  formatter={(value: any) => [formatCurrency(Number(value), currency), "Revenue"]}
                  contentStyle={{ background: "#0f172a", color: "#fff", borderRadius: "8px", fontSize: "12px", border: "none" }}
                />
                <Area type="monotone" dataKey="Revenue" stroke="#10b981" strokeWidth={2.5} fillOpacity={1} fill="url(#colorRevenue)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Distribution Pie Chart */}
        <div className="bg-white p-5 rounded-xl border border-slate-100 shadow-xs lg:col-span-4 space-y-4 flex flex-col justify-between">
          <div className="pb-2 border-b border-slate-100">
            <h3 className="font-semibold text-slate-800 text-sm">Quotation Pipeline Metrics</h3>
          </div>
          <div className="h-44 w-full flex justify-center items-center relative">
            {stats.total === 0 ? (
              <p className="text-slate-400 text-xs">No project logs generated yet</p>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={[
                      { name: "Approved", value: stats.approved },
                      { name: "Sent", value: stats.sent },
                      { name: "Draft", value: stats.draft },
                      { name: "Rejected", value: stats.rejected },
                      { name: "Expired", value: stats.expired }
                    ].filter(d => d.value > 0)}
                    cx="50%"
                    cy="50%"
                    innerRadius={45}
                    outerRadius={65}
                    paddingAngle={3}
                    dataKey="value"
                  >
                    {[0, 1, 2, 3, 4].map((index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip contentStyle={{ fontSize: "11px", borderRadius: "6px" }} />
                </PieChart>
              </ResponsiveContainer>
            )}
            <div className="absolute flex flex-col items-center">
              <span className="text-2xl font-extrabold text-slate-800">{stats.total}</span>
              <span className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider">Total Quotes</span>
            </div>
          </div>
          {/* Legend */}
          <div className="grid grid-cols-2 gap-2 text-xs pt-2 border-t border-slate-50">
            <div className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-[#10b981]" /> Approved ({stats.approved})</div>
            <div className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-[#3b82f6]" /> Sent ({stats.sent})</div>
            <div className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-[#f59e0b]" /> Draft ({stats.draft})</div>
            <div className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-[#ef4444]" /> Rejected ({stats.rejected})</div>
          </div>
        </div>
      </div>

      {/* Top Producers Bar row */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Top Company Revenues */}
        <div className="bg-white p-5 rounded-xl border border-slate-100 shadow-xs space-y-3">
          <h3 className="font-semibold text-slate-800 text-sm flex items-center gap-2">
            <Building className="w-4 h-4 text-theme" />
            Top Earning Companies (Approved)
          </h3>
          <div className="h-56">
            {topCompaniesData.length === 0 ? (
              <div className="h-full flex items-center justify-center text-xs text-slate-400">
                No active approved contracts registered yet.
              </div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={topCompaniesData} layout="vertical" margin={{ left: 20, right: 10, top: 10, bottom: 10 }}>
                  <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f1f5f9" />
                  <XAxis type="number" stroke="#94a3b8" fontSize={10} tickLine={false} />
                  <YAxis type="category" dataKey="name" stroke="#94a3b8" fontSize={10} width={100} tickLine={false} />
                  <Tooltip formatter={(value: any) => formatCurrency(Number(value), currency)} />
                  <Bar dataKey="Value" radius={[0, 4, 4, 0]}>
                    {topCompaniesData.map((entry, idx) => (
                      <Cell key={`cell-${idx}`} fill={entry.color} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>

        {/* Top Customers list */}
        <div className="bg-white p-5 rounded-xl border border-slate-100 shadow-xs space-y-3">
          <h3 className="font-semibold text-slate-800 text-sm flex items-center gap-2">
            <Users className="w-4 h-4 text-theme" />
            Top Capital Customers (Approved)
          </h3>
          <div className="h-56">
            {topCustomersData.length === 0 ? (
              <div className="h-full flex items-center justify-center text-xs text-slate-400">
                No customer transactions recorded yet.
              </div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={topCustomersData} margin={{ top: 10, right: 10, left: 10, bottom: 10 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis dataKey="name" stroke="#94a3b8" fontSize={10} tickLine={false} />
                  <YAxis stroke="#94a3b8" fontSize={10} tickLine={false} />
                  <Tooltip formatter={(value: any) => formatCurrency(Number(value), currency)} />
                  <Bar dataKey="Value" fill="#6366f1" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>
      </div>

      {/* Recent Proposals Row */}
      <div className="bg-white p-6 rounded-xl border border-slate-100 shadow-xs">
        <div className="flex justify-between items-center pb-4 border-b border-slate-100">
          <h3 className="font-semibold text-slate-800 text-sm">Recent Quotation Proposals</h3>
          <button
            onClick={() => onNavigate("builder")}
            className="text-xs text-indigo-600 hover:text-indigo-700 font-semibold flex items-center gap-1 hover:underline cursor-pointer"
          >
            Quotation Station →
          </button>
        </div>

        <div className="overflow-x-auto mt-4">
          {recentQuotations.length === 0 ? (
            <div className="py-8 text-center text-sm text-slate-400 font-medium">
              No quotations created yet. Click "Create Quotation" to launch one!
            </div>
          ) : (
            <table className="w-full text-sm text-left">
              <thead>
                <tr className="bg-slate-50 text-slate-500 text-xs font-semibold uppercase tracking-wider">
                  <th className="p-3 rounded-l-lg">Quote Number</th>
                  <th className="p-3">Customer Reference</th>
                  <th className="p-3">Issuing Company</th>
                  <th className="p-3">Date</th>
                  <th className="p-3">Amount</th>
                  <th className="p-3">Status</th>
                  <th className="p-3 rounded-r-lg text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700">
                {recentQuotations.map((q) => {
                  const companyName = companies.find(c => c.id === q.companyId)?.name || "Unknown Company";
                  const customerName = customers.find(c => c.id === q.customerId)?.name || "Unknown Customer";
                  const statusColors: any = {
                    Draft: "bg-slate-100 text-slate-800",
                    Sent: "bg-blue-50 text-blue-700 border border-blue-100",
                    Approved: "bg-emerald-50 text-emerald-700 border border-emerald-100",
                    Rejected: "bg-rose-50 text-rose-700 border border-rose-100",
                    Expired: "bg-amber-50 text-amber-600 border border-amber-100",
                  };
                  return (
                    <tr key={q.id} className="hover:bg-slate-50/50 transition-colors">
                      <td className="p-3 font-semibold text-cyan-700">{q.quotationNumber}</td>
                      <td className="p-3 font-medium">{customerName}</td>
                      <td className="p-3">{companyName}</td>
                      <td className="p-3 text-xs text-slate-500">{q.quotationDate}</td>
                      <td className="p-3 font-bold text-slate-950">{formatCurrency(q.finalAmount, currency)}</td>
                      <td className="p-3">
                        <span className={`px-2.5 py-0.5 rounded-full text-xs font-semibold ${statusColors[q.status] || "bg-slate-100"}`}>
                          {q.status}
                        </span>
                      </td>
                      <td className="p-3 text-right">
                        <button
                          onClick={() => onNavigate("builder", q.id)}
                          className="bg-slate-900 hover:bg-slate-800 active:scale-95 text-white text-xs px-3 py-1.5 rounded-md font-medium cursor-pointer"
                        >
                          Modify / View
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
}
