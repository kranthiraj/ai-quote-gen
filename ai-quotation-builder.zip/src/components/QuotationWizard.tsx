/**
 * @license
 * SPDX-License-Identifier: Apache-2.5
 */

import React, { useState, useEffect, useMemo, useRef } from "react";
import { 
  Plus, Search, Edit2, Copy, Trash2, Printer, Download, Eye, 
  Smartphone, Monitor, Tablet, FileText, CheckCircle, Sparkles, 
  Settings, UserPlus, Building2, RefreshCw, ChevronRight, History, 
  ToggleLeft, ToggleRight, Mic, Globe, Info, Clipboard, Loader2, Play,
  Database
} from "lucide-react";
import { Company, Customer, Item, Quotation, QuotationItem, ExtraCharge, VisualTemplate, UserRole, QuotationVersion } from "../types";
import { formatCurrency, numberToWords } from "../utils";
import { jsPDF } from "jspdf";
import html2canvas from "html2canvas";

interface QuotationWizardProps {
  quotations: Quotation[];
  companies: Company[];
  customers: Customer[];
  itemsDatabase: Item[];
  templates: VisualTemplate[];
  userRole: UserRole;
  currency: string;
  enableAi: boolean;
  onAddQuotation: (q: Omit<Quotation, "id" | "version">) => void;
  onUpdateQuotation: (id: string, q: Partial<Quotation> & { revisionComment?: string }) => void;
  onDeleteQuotation: (id: string) => void;
  onDuplicateQuotation: (id: string) => void;
  onAddCompany: (c: any) => void;
  onAddCustomer: (c: any) => void;
}

export default function QuotationWizard({
  quotations,
  companies,
  customers,
  itemsDatabase,
  templates,
  userRole,
  currency,
  enableAi,
  onAddQuotation,
  onUpdateQuotation,
  onDeleteQuotation,
  onDuplicateQuotation,
  onAddCompany,
  onAddCustomer
}: QuotationWizardProps) {
  // Views navigation list vs active editing workspace
  const [activeQuoteId, setActiveQuoteId] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterStatus, setFilterStatus] = useState<string>("All");
  const [filterCompany, setFilterCompany] = useState<string>("All");
  const [filterCustomer, setFilterCustomer] = useState<string>("All");

  // Device view modes: Desktop, Tablet, Mobile, Print
  const [previewDevice, setPreviewDevice] = useState<"desktop" | "tablet" | "mobile" | "print">("desktop");

  // Paper size options: a4, letter, legal
  const [paperSize, setPaperSize] = useState<"a4" | "letter" | "legal">("a4");

  // Dynamic vertical padding space for table line items
  const [itemVerticalPadding, setItemVerticalPadding] = useState<number>(8);

  // Measured dimensions of #quotation-print-container to calculate estimated page counts
  const [dimensions, setDimensions] = useState({ width: 794, height: 1123 });

  // Dynamic helper to retrieve physical dimensions and 96 DPI pixel equivalents
  const getPaperParams = (size: "a4" | "letter" | "legal") => {
    switch (size) {
      case "letter":
        return {
          widthMm: 215.9,
          heightMm: 279.4,
          jspdfFormat: "letter" as const,
          widthPx: 816,
          heightPx: 1056,
          label: "US Letter"
        };
      case "legal":
        return {
          widthMm: 215.9,
          heightMm: 355.6,
          jspdfFormat: "legal" as const,
          widthPx: 816,
          heightPx: 1344,
          label: "US Legal"
        };
      case "a4":
      default:
        return {
          widthMm: 210,
          heightMm: 297,
          jspdfFormat: "a4" as const,
          widthPx: 794,
          heightPx: 1123,
          label: "A4"
        };
    }
  };

  // Monitor preview element size to compute accurate live print estimates
  useEffect(() => {
    const container = document.getElementById("quotation-print-container");
    if (!container) return;

    const resizeObserver = new ResizeObserver((entries) => {
      for (const entry of entries) {
        setDimensions({
          width: entry.contentRect.width,
          height: entry.contentRect.height,
        });
      }
    });

    resizeObserver.observe(container);
    return () => resizeObserver.disconnect();
  }, [previewDevice, paperSize]);

  // Compute the estimated page count mathematically based on layout dimensions mapping
  const estimatedPages = useMemo(() => {
    const params = getPaperParams(paperSize);
    const currentWidth = dimensions.width || 794;
    const currentHeight = dimensions.height || 1123;
    
    // Map current height to target print resolution width
    const widthRatio = currentWidth / params.widthPx;
    const estimatedHeightAtPrintWidth = currentHeight * widthRatio;
    
    // Divide and round up (minimum of 1 page)
    return Math.max(1, Math.ceil(estimatedHeightAtPrintWidth / params.heightPx));
  }, [dimensions, paperSize]);

  // Visual dynamic visibility state fields toggles
  const [visibleFields, setVisibleFields] = useState({
    gst: true,
    pan: true,
    bankDetails: true,
    upiQr: true,
    signature: true,
    notes: true,
    terms: true,
    taxBreakdown: true,
    hsnCode: true,
    deliveryDate: true
  });

  // Inline Quick Builders Modal dialog states
  const [showCompanyModal, setShowCompanyModal] = useState(false);
  const [showCustomerModal, setShowCustomerModal] = useState(false);
  const [newCompanyForm, setNewCompanyForm] = useState({ name: "", email: "", address: "", mobile: "", state: "Maharashtra", country: "India" });
  const [newCustomerForm, setNewCustomerForm] = useState({ name: "", email: "", mobile: "", address: "", state: "Delhi", country: "India" });

  // AI Assistant states
  const [showAiAssistant, setShowAiAssistant] = useState(false);
  const [isGeneratingPDF, setIsGeneratingPDF] = useState(false);
  const [aiMainPrompt, setAiMainPrompt] = useState("");
  const [aiIsLoading, setAiIsLoading] = useState(false);
  const [aiAssistantTab, setAiAssistantTab] = useState<"generator" | "terms" | "parse" | "translate" | "recommend">("generator");
  
  // Custom AI operations states
  const [aiTermsIndustry, setAiTermsIndustry] = useState("IT");
  const [aiParseText, setAiParseText] = useState("");
  const [aiTranslateLang, setAiTranslateLang] = useState("Hindi");
  const [aiRecommendProduct, setAiRecommendProduct] = useState("");

  // Revision state parameters
  const [showRevisionsId, setShowRevisionsId] = useState<string | null>(null);
  const [revisionsList, setRevisionsList] = useState<QuotationVersion[]>([]);

  // Quote form state values
  const activeQuote = useMemo(() => {
    return quotations.find(q => q.id === activeQuoteId) || null;
  }, [quotations, activeQuoteId]);

  // Form local state
  const [formQuote, setFormQuote] = useState<Partial<Quotation>>({
    quotationNumber: "",
    quotationDate: new Date().toISOString().split("T")[0],
    validUntil: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
    companyId: "",
    customerId: "",
    templateId: "tmpl-1",
    items: [],
    extraCharges: [
      { id: "chg-1", name: "Packing & Delivery Charges", amount: 0, isActive: true },
      { id: "chg-2", name: "Installation & Setup fees", amount: 0, isActive: true }
    ],
    notes: "Thank you for doing business with us.",
    terms: "1. Validity lock standard is 15-Days.\n2. Taxes applicable post service approval.\n3. Goods once cleared from gates cannot be returned.",
    status: "Draft",
    isWatermarked: false,
    deliveryDate: ""
  });

  // Deep update form state when quotation selection changes
  useEffect(() => {
    if (activeQuote) {
      setFormQuote({
        ...activeQuote,
        items: activeQuote.items ? [...activeQuote.items] : [],
        extraCharges: activeQuote.extraCharges ? [...activeQuote.extraCharges] : []
      });
    } else {
      // Create template setup
      const nextNum = `QT-2026-${String(quotations.length + 1).padStart(3, "0")}`;
      setFormQuote({
        quotationNumber: nextNum,
        quotationDate: new Date().toISOString().split("T")[0],
        validUntil: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
        companyId: companies[0]?.id || "",
        customerId: customers[0]?.id || "",
        templateId: templates[0]?.id || "tmpl-1",
        items: [
          { name: "Sample Service Block", description: "Design project phase outline", quantity: 1, unit: "LS", price: 15000, discount: 0, taxPercentage: 18, total: 17700 }
        ],
        extraCharges: [
          { id: "chg-1", name: "Packing & Handling", amount: 0, isActive: true },
          { id: "chg-2", name: "Custom Site Setup", amount: 0, isActive: true }
        ],
        notes: "Thank you for choosing us.",
        terms: "1. 50% advance clearance requirements.\n2. Standard terms checkup applicable.\n3. Complete validation 15 days support.",
        status: "Draft",
        isWatermarked: false,
        deliveryDate: ""
      });
    }
  }, [activeQuoteId, activeQuote, companies, customers, templates, quotations.length]);

  // Calculations sync of totals and item list parameters
  const calculatedTotals = useMemo(() => {
    const items = formQuote.items || [];
    const extraCharges = formQuote.extraCharges || [];

    let subtotal = 0;
    let discountTotal = 0;
    let taxTotal = 0;

    items.forEach(it => {
      const lineCost = (it.price || 0) * (it.quantity || 1);
      const lineDisc = lineCost * ((it.discount || 0) / 100);
      const lineTaxable = lineCost - lineDisc;
      const lineTax = lineTaxable * ((it.taxPercentage || 0) / 100);

      subtotal += lineCost;
      discountTotal += lineDisc;
      taxTotal += lineTax;
    });

    const chargesTotal = extraCharges
      .filter(c => c.isActive)
      .reduce((sum, c) => sum + (c.amount || 0), 0);

    const finalAmount = subtotal - discountTotal + taxTotal + chargesTotal;

    return {
      subtotal: Math.round(subtotal),
      discountTotal: Math.round(discountTotal),
      taxTotal: Math.round(taxTotal),
      chargesTotal: Math.round(chargesTotal),
      finalAmount: Math.round(finalAmount)
    };
  }, [formQuote.items, formQuote.extraCharges]);

  // Synchronize totals to form quote parameters safely
  const synchronizedFormQuote = useMemo(() => {
    return {
      ...formQuote,
      ...calculatedTotals
    };
  }, [formQuote, calculatedTotals]);

  // Auto save simulator trigger
  const [saveIndicator, setSaveIndicator] = useState<"idle" | "saving" | "saved">("idle");
  const saveTimerRef = useRef<any>(null);

  const triggerAutoSave = () => {
    if (!activeQuoteId) return;
    setSaveIndicator("saving");
    if (saveTimerRef.current) clearTimeout(saveTimerRef.current);

    saveTimerRef.current = setTimeout(() => {
      onUpdateQuotation(activeQuoteId, {
        ...synchronizedFormQuote,
        revisionComment: "System automatic save sync parameter clearance"
      });
      setSaveIndicator("saved");
      setTimeout(() => setSaveIndicator("idle"), 2000);
    }, 4000);
  };

  const handleFieldChange = (key: keyof Quotation, value: any) => {
    setFormQuote(prev => {
      const updated = { ...prev, [key]: value };
      return updated;
    });
    triggerAutoSave();
  };

  // Add Item Line manually
  const handleAddLineItem = () => {
    const list = [...(formQuote.items || [])];
    list.push({
      name: "",
      description: "",
      quantity: 1,
      unit: "LS",
      price: 0,
      discount: 0,
      taxPercentage: 18,
      total: 0
    });
    setFormQuote(prev => ({ ...prev, items: list }));
    triggerAutoSave();
  };

  const handleRemoveLineItem = (index: number) => {
    const list = [...(formQuote.items || [])];
    list.splice(index, 1);
    setFormQuote(prev => ({ ...prev, items: list }));
    triggerAutoSave();
  };

  const handleUpdateLineItem = (index: number, fields: Partial<QuotationItem>) => {
    const list = [...(formQuote.items || [])];
    const prevItem = list[index];
    const updated = { ...prevItem, ...fields };

    // Calculate line total
    const sub = (updated.price || 0) * (updated.quantity || 1);
    const disc = sub * ((updated.discount || 0) / 100);
    const tax = (sub - disc) * ((updated.taxPercentage || 0) / 100);
    updated.total = Math.round(sub - disc + tax);

    list[index] = updated;
    setFormQuote(prev => ({ ...prev, items: list }));
    triggerAutoSave();
  };

  const handleChargeToggle = (id: string) => {
    const list = (formQuote.extraCharges || []).map(c =>
      c.id === id ? { ...c, isActive: !c.isActive } : c
    );
    setFormQuote(prev => ({ ...prev, extraCharges: list }));
    triggerAutoSave();
  };

  const handleChargeAmountChange = (id: string, val: number) => {
    const list = (formQuote.extraCharges || []).map(c =>
      c.id === id ? { ...c, amount: Number(val) } : c
    );
    setFormQuote(prev => ({ ...prev, extraCharges: list }));
    triggerAutoSave();
  };

  // Autocomplete Insert from catalog database click
  const handleInsertFromItemDatabase = (item: Item) => {
    const list = [...(formQuote.items || [])];
    list.push({
      itemId: item.id,
      name: item.name,
      description: item.description || "",
      unit: item.unit,
      price: item.rate,
      quantity: 1,
      discount: 0,
      taxPercentage: item.taxPercentage,
      hsnCode: item.hsnCode || "",
      sacCode: item.sacCode || "",
      total: Math.round(item.rate + (item.rate * (item.taxPercentage / 100)))
    });
    setFormQuote(prev => ({ ...prev, items: list }));
    triggerAutoSave();
    alert(`Successfully loaded '${item.name}' into quotation!`);
  };

  // Open revisions list API
  const handleOpenRevisions = async (id: string) => {
    try {
      setShowRevisionsId(id);
      const res = await fetch(`/api/quotations/versions/${id}`);
      const data = await res.json();
      setRevisionsList(data || []);
    } catch (e) {
      alert("Failed loading versions logs.");
    }
  };

  const handleApplyVersionRollback = (ver: QuotationVersion) => {
    if (confirm(`Rollback quotation to version v${ver.version}?`)) {
      setFormQuote({ ...ver.data });
      onUpdateQuotation(ver.quotationId, {
        ...ver.data,
        revisionComment: `Rollback selection to version state v${ver.version}`
      });
      setShowRevisionsId(null);
      alert("Successfully loaded historical rollback state!");
    }
  };

  // Inline additions
  const handleAddCompanyInline = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCompanyForm.name || !newCompanyForm.email) return;
    onAddCompany(newCompanyForm);
    setShowCompanyModal(false);
    setNewCompanyForm({ name: "", email: "", address: "", mobile: "", state: "Maharashtra", country: "India" });
  };

  const handleAddCustomerInline = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCustomerForm.name || !newCustomerForm.email) return;
    onAddCustomer(newCustomerForm);
    setShowCustomerModal(false);
    setNewCustomerForm({ name: "", email: "", mobile: "", address: "", state: "Delhi", country: "India" });
  };

  // Perform Gemini AI call proxies
  const handleAiQuotationGen = async () => {
    if (!aiMainPrompt) return;
    try {
      setAiIsLoading(true);
      const res = await fetch("/api/ai/generate-quotation", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt: aiMainPrompt })
      });
      const data = await res.json();
      if (data.error) {
        alert(data.error);
        return;
      }

      const formattedItems = (data.items || []).map((it: any) => ({
        name: it.name,
        description: it.description || "",
        quantity: Number(it.quantity || 1),
        unit: it.unit || "LS",
        price: Number(it.price || 0),
        discount: 0,
        taxPercentage: Number(it.taxPercentage || 18),
        total: Math.round(Number(it.price || 0) * (1 + (Number(it.taxPercentage || 18) / 100)))
      }));

      setFormQuote(prev => ({
        ...prev,
        items: formattedItems,
        terms: data.terms || prev.terms,
        notes: data.notes || prev.notes
      }));

      setAiMainPrompt("");
      setShowAiAssistant(false);
      alert("Success! Gemini designed quote blocks with items and parameters successfully.");
    } catch (e: any) {
      alert("AI generator call failed: " + e.message);
    } finally {
      setAiIsLoading(false);
    }
  };

  const handleAiTermsGen = async () => {
    try {
      setAiIsLoading(true);
      const res = await fetch("/api/ai/generate-quotation", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt: `Generate professional contract terms block for industry: ${aiTermsIndustry}` })
      });
      const data = await res.json();
      if (data.terms) {
        setFormQuote(prev => ({ ...prev, terms: data.terms }));
        alert("Downloaded industry specific standard terms!");
      }
    } catch (e) {
      alert("Failed terms loading.");
    } finally {
      setAiIsLoading(false);
    }
  };

  const handleAiParserGen = async () => {
    if (!aiParseText) return;
    try {
      setAiIsLoading(true);
      const res = await fetch("/api/ai/parse-customer", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ rawText: aiParseText })
      });
      const data = await res.json();
      if (data.name) {
        // Register or inline populate customer modal
        setNewCustomerForm({
          name: data.name,
          companyName: data.companyName,
          gstin: data.gstin,
          pan: data.pan,
          address: data.address,
          mobile: data.mobile || "+91 99999 11111",
          email: data.email || "client@company.com",
          state: data.state || "Delhi",
          country: data.country || "India"
        } as any);
        setAiParseText("");
        setShowCustomerModal(true);
        alert("Extracted parameters! Verify customer cards in forms below.");
      }
    } catch (e) {
      alert("Parse text failed.");
    } finally {
      setAiIsLoading(false);
    }
  };

  // Perform translation
  const handleTranslateQuote = async () => {
    try {
      setAiIsLoading(true);
      const currentNotes = formQuote.notes || "";
      const currentTerms = formQuote.terms || "";

      const resNotes = await fetch("/api/ai/translate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: currentNotes, language: aiTranslateLang })
      });
      const dataN = await resNotes.json();

      const resTerms = await fetch("/api/ai/translate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: currentTerms, language: aiTranslateLang })
      });
      const dataT = await resTerms.json();

      setFormQuote(prev => ({
        ...prev,
        notes: dataN.translatedText || prev.notes,
        terms: dataT.translatedText || prev.terms
      }));

      alert(`Translated terms and notes successfully to ${aiTranslateLang}!`);
    } catch (e) {
      alert("Translation process failed.");
    } finally {
      setAiIsLoading(false);
    }
  };

  // Perform saving action
  const handleSaveQuotation = () => {
    const payload = { ...synchronizedFormQuote };
    if (activeQuoteId) {
      onUpdateQuotation(activeQuoteId, payload);
      alert("Changes applied and saved to local JSON catalog!");
    } else {
      onAddQuotation(payload as any);
      alert("New Quotation Sheet created and logged!");
    }
    setActiveQuoteId(null);
  };

  // Printing trigger
  const handleTriggerPrint = () => {
    window.print();
  };

  // Filtering calculations
  const filteredQuotations = useMemo(() => {
    return quotations.filter(q => {
      const matchSearch =
        q.quotationNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
        customers.find(c => c.id === q.customerId)?.name.toLowerCase().includes(searchTerm.toLowerCase());
      
      const matchStatus = filterStatus === "All" || q.status === filterStatus;
      const matchCompany = filterCompany === "All" || q.companyId === filterCompany;
      const matchCustomer = filterCustomer === "All" || q.customerId === filterCustomer;

      return matchSearch && matchStatus && matchCompany && matchCustomer;
    });
  }, [quotations, searchTerm, filterStatus, filterCompany, filterCustomer, customers]);

  // Read active formatting styles
  const activeCompanyRecord = useMemo(() => {
    return companies.find(c => c.id === (formQuote.companyId || synchronizedFormQuote.companyId));
  }, [companies, formQuote.companyId, synchronizedFormQuote.companyId]);

  const activeCustomerRecord = useMemo(() => {
    return customers.find(c => c.id === (formQuote.customerId || synchronizedFormQuote.customerId));
  }, [customers, formQuote.customerId, synchronizedFormQuote.customerId]);

  const activeTemplateRecord = useMemo(() => {
    return templates.find(t => t.id === (formQuote.templateId || "tmpl-1"));
  }, [templates, formQuote.templateId]);

  // Helper function to dynamically convert oklch CSS color declarations to clean, compatible RGB/RGBA
  const oklchToRgb = (oklchStr: string): string => {
    if (typeof oklchStr !== "string" || !oklchStr.toLowerCase().includes("oklch")) {
      return oklchStr;
    }
    return oklchStr.replace(
      /oklch\(\s*([\d.%]+)\s+([\d.%]+)\s+([\d.deg|rad|turn|grad%]+)(?:\s*\/\s*([\d.%]+))?\s*\)/gi,
      (match, lStr, cStr, hStr, aStr) => {
        let L = parseFloat(lStr);
        if (lStr.includes("%")) L /= 100;

        let C = parseFloat(cStr);
        if (cStr.includes("%")) C /= 100;

        let H = parseFloat(hStr);
        if (hStr.includes("rad")) {
          H = (H * 180) / Math.PI;
        } else if (hStr.includes("turn")) {
          H = H * 360;
        } else if (hStr.includes("grad")) {
          H = H * 0.9;
        }
        H = ((H % 360) + 360) % 360;

        let alpha = 1;
        if (aStr) {
          alpha = parseFloat(aStr);
          if (aStr.includes("%")) alpha /= 100;
        }

        // OKLCH to OKLab
        const hRad = (H * Math.PI) / 180;
        const lab_a = C * Math.cos(hRad);
        const lab_b = C * Math.sin(hRad);

        // OKLab to LMS
        const l_ = L + 0.3963377774 * lab_a + 0.2158037573 * lab_b;
        const m_ = L - 0.1055613458 * lab_a - 0.0638541728 * lab_b;
        const s_ = L - 0.0894841775 * lab_a - 1.291485548 * lab_b;

        // LMS cubic root back-transformation
        const l = l_ * l_ * l_;
        const m = m_ * m_ * m_;
        const s = s_ * s_ * s_;

        // LMS to linear RGB
        const rLinear = +4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * s;
        const gLinear = -1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * s;
        const bLinear = -0.0041960863 * l - 0.7034186147 * m + 1.707614701 * s;

        // Linear RGB to standard sRGB gamma correction
        const toSRGB = (x: number) => {
          if (x <= 0.0031308) {
            return 12.92 * x;
          }
          return 1.055 * Math.pow(x, 1 / 2.4) - 0.055;
        };

        const r = Math.max(0, Math.min(255, Math.round(toSRGB(rLinear) * 255)));
        const g = Math.max(0, Math.min(255, Math.round(toSRGB(gLinear) * 255)));
        const b = Math.max(0, Math.min(255, Math.round(toSRGB(bLinear) * 255)));

        if (alpha === 1) {
          return `rgb(${r}, ${g}, ${b})`;
        } else {
          return `rgba(${r}, ${g}, ${b}, ${alpha})`;
        }
      }
    );
  };

  // High-quality A4 PDF Generation handler using jspdf + html2canvas
  const handleDownloadPDF = async () => {
    const container = document.getElementById("quotation-print-container");
    if (!container) return;

    setIsGeneratingPDF(true);

    const mainFuncPatches: { obj: any; prop: string; original: Function }[] = [];
    const stylesToRestore: { element: HTMLStyleElement; originalText: string }[] = [];

    const applyMainPatches = () => {
      // 1. Sanitize all stylesheet style tags in the main document to clear static oklch usage
      try {
        const styleElements = document.querySelectorAll("style");
        styleElements.forEach((el) => {
          if (el.textContent && el.textContent.toLowerCase().includes("oklch")) {
            stylesToRestore.push({ element: el, originalText: el.textContent });
            el.textContent = oklchToRgb(el.textContent);
          }
        });
      } catch (e) {
        console.warn("Failed to sanitize <style> tags:", e);
      }

      // 2. Patch window.getComputedStyle to translate oklch to rgb cleanly without Illegal Invocation
      const originalGetComputedStyle = window.getComputedStyle;
      if (originalGetComputedStyle) {
        window.getComputedStyle = function (element, pseudoElt) {
          const style = originalGetComputedStyle.call(this, element, pseudoElt);
          return new Proxy(style, {
            get(target, prop, receiver) {
              const val = Reflect.get(target, prop, target);
              if (typeof val === "function") {
                return function (this: any, ...args: any[]) {
                  const result = val.apply(this === receiver ? target : this, args);
                  return typeof result === "string" ? oklchToRgb(result) : result;
                };
              }
              if (typeof val === "string") {
                return oklchToRgb(val);
              }
              return val;
            }
          });
        };
        mainFuncPatches.push({ obj: window, prop: "getComputedStyle", original: originalGetComputedStyle });
      }
    };

    const restoreMainPatches = () => {
      // Restore stylesToRestore
      for (const item of stylesToRestore) {
        try {
          item.element.textContent = item.originalText;
        } catch (e) {
          console.error("Failed to restore style tag:", e);
        }
      }
      // Restore functions
      for (let i = mainFuncPatches.length - 1; i >= 0; i--) {
        const fp = mainFuncPatches[i];
        try {
          (fp.obj as any)[fp.prop] = fp.original;
        } catch (e) {
          console.error(`Failed to restore function ${fp.prop}:`, e);
        }
      }
    };

    try {
      applyMainPatches();

      // Save original visual properties for clean restoration
      const originalWidth = container.style.width;
      const originalMinWidth = container.style.minWidth;
      const originalMaxWidth = container.style.maxWidth;
      const originalPadding = container.style.padding;
      const originalShadow = container.style.boxShadow;
      const originalBorder = container.style.border;

      const paperParams = getPaperParams(paperSize);

      // Force a unified standard width representing the selected paper size at 96 DPI for perfect proportions
      container.style.width = `${paperParams.widthPx}px`;
      container.style.minWidth = `${paperParams.widthPx}px`;
      container.style.maxWidth = `${paperParams.widthPx}px`;
      container.style.padding = "20mm";
      container.style.boxShadow = "none";
      container.style.border = "none";

      // Allow rendering cycles to complete
      await new Promise((resolve) => setTimeout(resolve, 150));

      // Calculate a dynamic scale factor based on the number of line items
      // For short quotes (fewer items), we use a high scale factor (up to 3.0) for maximum text sharpness.
      // For longer quotes, we adjust down gracefully to prevent browser canvas size limits and ensure crisp text without rendering crashes.
      const itemCount = (synchronizedFormQuote.items || []).length;
      let dynamicScale = 2.5;
      if (itemCount <= 5) {
        dynamicScale = 3.0; // Extra sharp resolution for small single-page documents
      } else if (itemCount <= 12) {
        dynamicScale = 2.6; // High-grade sharpness for medium documents
      } else if (itemCount <= 22) {
        dynamicScale = 2.2; // Perfectly balanced sharpness and memory layout for longer multi-page documents
      } else {
        dynamicScale = 1.8; // Robust and reliable rendering scale for extremely long quotations
      }

      const canvas = await html2canvas(container, {
        scale: dynamicScale,
        useCORS: true,
        allowTaint: false,
        backgroundColor: activeTemplateRecord?.bgColor || "#ffffff",
        logging: false,
        windowWidth: 1200, // Force desktop viewport width during rendering so A4 doesn't squeeze on mobile device viewport
        onclone: (clonedDoc) => {
          const clonedWin = clonedDoc.defaultView;
          if (!clonedWin) return;

          // Sanitise cloned styles tags text directly
          try {
            const clonedStyles = clonedDoc.querySelectorAll("style");
            clonedStyles.forEach((el) => {
              if (el.textContent && el.textContent.toLowerCase().includes("oklch")) {
                el.textContent = oklchToRgb(el.textContent);
              }
            });
          } catch (e) {
            // Ignore stylesheet errors
          }

          // 1. Monkey-patch window.getComputedStyle in the cloned view context
          const originalGetComputedStyle = clonedWin.getComputedStyle;
          if (originalGetComputedStyle) {
            clonedWin.getComputedStyle = function (element, pseudoElt) {
              const style = originalGetComputedStyle.call(this, element, pseudoElt);
              
              // Return a live proxy of the style declaration to filter out oklch values dynamically without Illegal Invocation
              return new Proxy(style, {
                get(target, prop, receiver) {
                  const val = Reflect.get(target, prop, target);
                  if (typeof val === "function") {
                    return function (this: any, ...args: any[]) {
                      const result = val.apply(this === receiver ? target : this, args);
                      return typeof result === "string" ? oklchToRgb(result) : result;
                    };
                  }
                  if (typeof val === "string") {
                    return oklchToRgb(val);
                  }
                  return val;
                }
              });
            };
          }

          // 2. Force override of oklch inline styles for all elements in the target cloned tree
          const els = clonedDoc.getElementsByTagName("*");
          for (let i = 0; i < els.length; i++) {
            const el = els[i] as HTMLElement;
            if (el.style && el.style.cssText) {
              if (el.style.cssText.toLowerCase().includes("oklch")) {
                el.style.cssText = oklchToRgb(el.style.cssText);
              }
            }
          }
        }
      });

      // Restore user visual parameters instantly
      container.style.width = originalWidth;
      container.style.minWidth = originalMinWidth;
      container.style.maxWidth = originalMaxWidth;
      container.style.padding = originalPadding;
      container.style.boxShadow = originalShadow;
      container.style.border = originalBorder;

      const imgWidth = paperParams.widthMm; // layout width in physical mm
      const pageHeight = paperParams.heightMm; // layout height in physical mm
      const imgHeight = (canvas.height * imgWidth) / canvas.width;
      
      const pdf = new jsPDF("p", "mm", paperParams.jspdfFormat);
      const imgData = canvas.toDataURL("image/jpeg", 0.98);

      let heightLeft = imgHeight;
      let position = 0;

      // Add main page
      pdf.addImage(imgData, "JPEG", 0, position, imgWidth, imgHeight, undefined, "FAST");
      heightLeft -= pageHeight;

      // Stagger overflow cleanly onto multiple pages if required
      while (heightLeft > 0) {
        position = heightLeft - imgHeight;
        pdf.addPage();
        pdf.addImage(imgData, "JPEG", 0, position, imgWidth, imgHeight, undefined, "FAST");
        heightLeft -= pageHeight;
      }

      // Generate pristine download filename
      const filename = `Quotation_${synchronizedFormQuote.quotationNumber || "Sheet"}.pdf`;
      pdf.save(filename);
    } catch (error) {
      console.error("Error generating PDF:", error);
      alert("An error occurred during high-quality PDF rendering. Please try again.");
    } finally {
      restoreMainPatches();
      setIsGeneratingPDF(false);
    }
  };

  return (
    <div className="space-y-6">
      {!activeQuoteId ? (
        // LIST VIEW
        <div className="space-y-4">
          <div className="bg-white p-5 rounded-xl border border-slate-100 shadow-xs flex flex-wrap gap-4 items-center justify-between">
            <div className="relative w-full sm:w-72">
              <Search className="w-5 h-5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder="Search reference num or customer name..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg pl-10 pr-4 py-2 text-sm focus:outline-none"
              />
            </div>

            {/* Quick selectors row */}
            <div className="flex flex-wrap items-center gap-2.5">
              <select
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value)}
                className="bg-slate-50 border border-slate-200 text-xs px-2.5 py-2.5 rounded-lg focus:outline-none font-medium text-slate-700"
              >
                <option value="All">All statuses</option>
                <option value="Draft">Draft</option>
                <option value="Sent">Sent</option>
                <option value="Approved">Approved</option>
                <option value="Rejected">Rejected</option>
                <option value="Expired">Expired</option>
              </select>

              <select
                value={filterCompany}
                onChange={(e) => setFilterCompany(e.target.value)}
                className="bg-slate-50 border border-slate-200 text-xs px-2.5 py-2.5 rounded-lg focus:outline-none font-medium text-slate-700"
              >
                <option value="All">All companies</option>
                {companies.map(c => (
                  <option key={c.id} value={c.id}>{c.name}</option>
                ))}
              </select>

              <button
                onClick={() => {
                  setActiveQuoteId("new");
                }}
                className="flex items-center gap-2 bg-slate-900 border border-slate-900 text-white hover:bg-slate-800 font-medium px-4 py-2.5 rounded-lg text-sm cursor-pointer"
              >
                <Plus className="w-4 h-4" /> Add Quote Sheet
              </button>
            </div>
          </div>

          <div className="bg-white rounded-xl border border-slate-100 shadow-xs divide-y divide-slate-100 overflow-hidden text-sm">
            {filteredQuotations.length === 0 ? (
              <div className="py-12 text-center text-slate-400 font-semibold">
                No matching recorded quotations generated yet.
              </div>
            ) : (
              filteredQuotations.map((q) => {
                const compName = companies.find(c => c.id === q.companyId)?.name || "Unknown Company";
                const cName = customers.find(c => c.id === q.customerId)?.name || "Unknown Customer";
                const statusColors: any = {
                  Draft: "bg-slate-100 text-slate-800",
                  Sent: "bg-blue-50 text-blue-700 border-blue-100",
                  Approved: "bg-emerald-50 text-emerald-700 border-emerald-100",
                  Rejected: "bg-rose-50 text-rose-700 border-rose-100",
                  Expired: "bg-amber-50 text-amber-600 border border-amber-100",
                };
                return (
                  <div key={q.id} className="p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 hover:bg-slate-50/50 transition-colors">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2.5">
                        <span className="font-extrabold text-cyan-800 text-sm">{q.quotationNumber}</span>
                        <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${statusColors[q.status] || "bg-slate-100"}`}>
                          {q.status}
                        </span>
                      </div>
                      <p className="font-medium text-slate-900">{cName} <span className="text-slate-400 font-normal">via {compName}</span></p>
                      <div className="text-xs text-slate-500 flex flex-wrap gap-x-4 pt-1">
                        <span><strong>Issue Date:</strong> {q.quotationDate}</span>
                        <span><strong>Expiration:</strong> {q.validUntil}</span>
                        <span><strong>Version:</strong> v{q.version || 1}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-4 self-stretch sm:self-center justify-between border-t sm:border-0 pt-3 sm:pt-0">
                      <div className="text-left sm:text-right">
                        <span className="block text-xs text-slate-400 font-semibold uppercase tracking-wider">Proposal Value</span>
                        <span className="text-base font-bold text-slate-950">{formatCurrency(q.finalAmount, currency)}</span>
                      </div>

                      <div className="flex items-center gap-1.5 shrink-0">
                        {/* Ver block */}
                        <button
                          onClick={() => handleOpenRevisions(q.id)}
                          className="p-2 text-slate-500 hover:text-indigo-600 hover:bg-slate-50 rounded-lg"
                          title="Revision History Logs"
                        >
                          <History className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => setActiveQuoteId(q.id)}
                          className="p-2 text-slate-500 hover:text-slate-950 hover:bg-slate-50 rounded-lg cursor-pointer"
                          title="Write or Edit Quotation"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => onDuplicateQuotation(q.id)}
                          className="p-2 text-slate-500 hover:text-cyan-600 hover:bg-slate-50 rounded-lg cursor-pointer"
                          title="Duplicate/Clone Quote Board"
                        >
                          <Copy className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => {
                            if (confirm(`Remove records for quote ${q.quotationNumber}?`)) onDeleteQuotation(q.id);
                          }}
                          className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg cursor-pointer"
                          title="Delete Quote permanently"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      ) : (
        // EDIT ACTION BUILDER
        <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 items-start" id="active-wizard-page">
          {/* LEFT WIZARD CONTROLS */}
          <div className="col-span-12 xl:col-span-7 bg-white rounded-xl border border-slate-100 shadow-xs p-6 space-y-6">
            <div className="flex justify-between items-center pb-4 border-b border-slate-150">
              <div className="space-y-0.5">
                <span className="text-xs uppercase tracking-wider text-slate-400 font-bold font-mono">Building Area Workstation</span>
                <h3 className="font-bold text-slate-900 text-lg flex items-center gap-2">
                  Quote ID: {synchronizedFormQuote.quotationNumber}
                  {saveIndicator === "saving" && <span className="text-[10px] bg-slate-100 text-slate-500 px-2 py-0.5 rounded font-normal animate-pulse">Auto Saving...</span>}
                  {saveIndicator === "saved" && <span className="text-[10px] bg-emerald-50 text-emerald-700 px-2 py-0.5 rounded font-bold">Autosaved ✔</span>}
                </h3>
              </div>
              <button
                onClick={() => setActiveQuoteId(null)}
                className="text-xs bg-slate-50 hover:bg-slate-100 border border-slate-200 text-slate-700 px-3 py-1.5 rounded-lg font-medium cursor-pointer"
              >
                ← Back to overview
              </button>
            </div>

            {/* AI Assistant mini launcher */}
            {enableAi && (
              <div className="bg-gradient-to-r from-violet-50 to-indigo-50 border border-violet-100 p-4 rounded-xl flex items-center justify-between gap-4">
                <div className="space-y-1">
                  <h4 className="text-xs font-bold text-violet-950 flex items-center gap-1.5"><Sparkles className="w-4 h-4 text-violet-700" /> Gemini Smart AI Assistant Panel</h4>
                  <p className="text-[11px] text-violet-600 leading-normal">
                    Generate service descriptions, prices, custom tax suggestions, parse pasted raw client text, and auto translate terms directly.
                  </p>
                </div>
                <button
                  onClick={() => setShowAiAssistant(true)}
                  className="bg-violet-600 text-white font-semibold text-xs px-3.5 py-2.5 rounded-lg shadow hover:bg-violet-700 transition"
                >
                  Configure AI
                </button>
              </div>
            )}

            {/* Main Form controls block */}
            <div className="space-y-5 text-sm">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-slate-50/50 p-4 rounded-xl border border-slate-100">
                <div className="col-span-2 sm:col-span-1">
                  <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">Quote ID Code</label>
                  <input
                    type="text"
                    value={formQuote.quotationNumber}
                    onChange={(e) => handleFieldChange("quotationNumber", e.target.value)}
                    className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none"
                  />
                </div>

                <div className="col-span-2 sm:col-span-1">
                  <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">Status selection</label>
                  <select
                    value={formQuote.status}
                    onChange={(e) => handleFieldChange("status", e.target.value)}
                    className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none font-medium"
                  >
                    <option value="Draft">Draft</option>
                    <option value="Sent">Sent</option>
                    <option value="Approved">Approved</option>
                    <option value="Rejected">Rejected</option>
                    <option value="Expired">Expired</option>
                  </select>
                </div>

                <div className="col-span-2 sm:col-span-1">
                  <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5">Issue Date</label>
                  <input
                    type="date"
                    value={formQuote.quotationDate}
                    onChange={(e) => handleFieldChange("quotationDate", e.target.value)}
                    className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none"
                  />
                </div>

                <div className="col-span-2 sm:col-span-1">
                  <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5">Valid Until</label>
                  <input
                    type="date"
                    value={formQuote.validUntil}
                    onChange={(e) => handleFieldChange("validUntil", e.target.value)}
                    className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none"
                  />
                </div>
              </div>

              {/* Dynamic Auto selectors with inline additions */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <div className="flex justify-between items-center mb-1.5">
                    <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider">Select Issuing Company</label>
                    <button
                      type="button"
                      onClick={() => setShowCompanyModal(true)}
                      className="text-indigo-600 hover:text-indigo-700 text-[10px] font-bold flex items-center gap-0.5 uppercase cursor-pointer"
                    >
                      <UserPlus className="w-3.5 h-3.5" /> add new
                    </button>
                  </div>
                  <select
                    value={formQuote.companyId}
                    onChange={(e) => handleFieldChange("companyId", e.target.value)}
                    className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-550"
                  >
                    <option value="">-- Choose Company --</option>
                    {companies.map(c => (
                      <option key={c.id} value={c.id}>{c.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <div className="flex justify-between items-center mb-1.5">
                    <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider">Select Customer</label>
                    <button
                      type="button"
                      onClick={() => setShowCustomerModal(true)}
                      className="text-indigo-600 hover:text-indigo-700 text-[10px] font-bold flex items-center gap-0.5 uppercase cursor-pointer"
                    >
                      <UserPlus className="w-3.5 h-3.5" /> add new
                    </button>
                  </div>
                  <select
                    value={formQuote.customerId}
                    onChange={(e) => handleFieldChange("customerId", e.target.value)}
                    className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-550"
                  >
                    <option value="">-- Choose Customer --</option>
                    {customers.map(cust => (
                      <option key={cust.id} value={cust.id}>{cust.name} {cust.companyName ? `(${cust.companyName})` : ""}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Item Library One-Click Insertion Drawbar */}
              <div className="space-y-1.5 p-3 bg-indigo-50/40 border border-indigo-100 rounded-xl">
                <span className="text-[10px] text-indigo-700 font-extrabold uppercase block tracking-wider flex items-center gap-1">
                  <Database className="w-3.5 h-3.5" /> One-Click Item Library Catalog Insert
                </span>
                <div className="flex gap-2 overflow-x-auto py-1">
                  {itemsDatabase.map(it => (
                    <button
                      key={it.id}
                      type="button"
                      onClick={() => handleInsertFromItemDatabase(it)}
                      className="bg-white hover:bg-indigo-50 border border-slate-150 rounded-lg px-3 py-1.5 text-xs text-slate-700 font-medium whitespace-nowrap cursor-pointer hover:border-indigo-400 shadow-xs transition"
                    >
                      + {it.name} (₹{it.rate})
                    </button>
                  ))}
                </div>
              </div>

              {/* Real Editable spreadsheet like Items Grid table */}
              <div className="space-y-2.5">
                <div className="flex justify-between items-center pb-2 border-b border-slate-100">
                  <h4 className="font-semibold text-slate-800 text-xs uppercase tracking-wider">Services / Products Spreadsheet</h4>
                  <button
                    type="button"
                    onClick={handleAddLineItem}
                    className="flex items-center gap-1 bg-slate-900 border border-slate-900 text-white font-medium hover:bg-slate-800 px-3 py-1.5 rounded-lg text-xs cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" /> Add custom line
                  </button>
                </div>

                <div className="hidden md:block overflow-x-auto border border-slate-150 rounded-xl bg-white">
                  <table className="w-full text-xs text-left">
                    <thead className="bg-[#f8fafc] text-slate-500 font-semibold uppercase tracking-wider">
                      <tr>
                        <th className="p-2.5">Name *</th>
                        <th className="p-2.5">Description</th>
                        <th className="p-2.5 w-16">Qty</th>
                        <th className="p-2.5 w-24">Price</th>
                        <th className="p-2.5 w-16">Disc%</th>
                        <th className="p-2.5 w-16">Tax%</th>
                        <th className="p-2.5 w-16 text-right">Total</th>
                        <th className="p-2.5 text-center w-10">Rm</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-150">
                      {(formQuote.items || []).map((it, idx) => (
                        <tr key={idx} className="hover:bg-slate-50/50">
                          <td className="p-2">
                            <input
                              type="text"
                              value={it.name}
                              onChange={(e) => handleUpdateLineItem(idx, { name: e.target.value })}
                              placeholder="Service title"
                              className="w-full bg-slate-50 px-2 py-1 rounded"
                            />
                          </td>
                          <td className="p-2">
                            <input
                              type="text"
                              value={it.description}
                              onChange={(e) => handleUpdateLineItem(idx, { description: e.target.value })}
                              placeholder="Scope or details"
                              className="w-full bg-slate-50 px-2 py-1 rounded"
                            />
                          </td>
                          <td className="p-2">
                            <input
                              type="number"
                              min="1"
                              value={it.quantity}
                              onChange={(e) => handleUpdateLineItem(idx, { quantity: Number(e.target.value || 1) })}
                              className="w-full bg-slate-50 px-1 py-1 rounded text-center"
                            />
                          </td>
                          <td className="p-2">
                            <input
                              type="number"
                              min="0"
                              value={it.price}
                              onChange={(e) => handleUpdateLineItem(idx, { price: Number(e.target.value || 0) })}
                              className="w-full bg-slate-50 px-1.5 py-1 rounded font-medium"
                            />
                          </td>
                          <td className="p-2">
                            <input
                              type="number"
                              min="0"
                              max="100"
                              value={it.discount}
                              onChange={(e) => handleUpdateLineItem(idx, { discount: Number(e.target.value || 0) })}
                              className="w-full bg-slate-50 px-1 py-1 rounded text-center"
                            />
                          </td>
                          <td className="p-2">
                            <select
                              value={it.taxPercentage}
                              onChange={(e) => handleUpdateLineItem(idx, { taxPercentage: Number(e.target.value) })}
                              className="w-full bg-slate-50 px-1 py-1 rounded"
                            >
                              <option value="0">0%</option>
                              <option value="5">5%</option>
                              <option value="12">12%</option>
                              <option value="18">18%</option>
                              <option value="28">28%</option>
                            </select>
                          </td>
                          <td className="p-2 font-bold text-slate-800 text-right text-xs">
                            {formatCurrency(it.total, currency)}
                          </td>
                          <td className="p-2 text-center">
                            <button
                              type="button"
                              onClick={() => handleRemoveLineItem(idx)}
                              className="text-rose-500 hover:text-rose-600 rounded p-1"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Mobile Friendly Cards Layer */}
                <div className="block md:hidden space-y-4">
                  {(formQuote.items || []).map((it, idx) => (
                    <div key={idx} className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-3 relative">
                      <div className="flex justify-between items-center pb-2 border-b border-slate-100">
                        <span className="text-xs font-bold text-indigo-600">Item #{idx + 1}</span>
                        <button
                          type="button"
                          onClick={() => handleRemoveLineItem(idx)}
                          className="text-rose-500 hover:text-rose-600 rounded p-1 flex items-center gap-1 text-[11px] font-medium"
                        >
                          <Trash2 className="w-3.5 h-3.5" /> Remove
                        </button>
                      </div>

                      <div className="space-y-3 text-xs">
                        <div>
                          <label className="block text-[10px] font-semibold text-slate-500 uppercase tracking-wider mb-1">Name *</label>
                          <input
                            type="text"
                            value={it.name}
                            onChange={(e) => handleUpdateLineItem(idx, { name: e.target.value })}
                            placeholder="Service title"
                            className="w-full bg-white border border-slate-200 px-3 py-2 rounded-lg"
                          />
                        </div>

                        <div>
                          <label className="block text-[10px] font-semibold text-slate-500 uppercase tracking-wider mb-1">Description</label>
                          <input
                            type="text"
                            value={it.description}
                            onChange={(e) => handleUpdateLineItem(idx, { description: e.target.value })}
                            placeholder="Scope or details"
                            className="w-full bg-white border border-slate-200 px-3 py-2 rounded-lg"
                          />
                        </div>

                        <div className="grid grid-cols-2 gap-3">
                          <div>
                            <label className="block text-[10px] font-semibold text-slate-500 uppercase tracking-wider mb-1">Quantity</label>
                            <input
                              type="number"
                              min="1"
                              value={it.quantity}
                              onChange={(e) => handleUpdateLineItem(idx, { quantity: Number(e.target.value || 1) })}
                              className="w-full bg-white border border-slate-200 px-3 py-2 rounded-lg text-center"
                            />
                          </div>

                          <div>
                            <label className="block text-[10px] font-semibold text-slate-500 uppercase tracking-wider mb-1">Price ({currency === "INR" ? "₹" : "$"})</label>
                            <input
                              type="number"
                              min="0"
                              value={it.price}
                              onChange={(e) => handleUpdateLineItem(idx, { price: Number(e.target.value || 0) })}
                              className="w-full bg-white border border-slate-200 px-3 py-2 rounded-lg text-center font-medium"
                            />
                          </div>
                        </div>

                        <div className="grid grid-cols-2 gap-3">
                          <div>
                            <label className="block text-[10px] font-semibold text-slate-500 uppercase tracking-wider mb-1">Discount %</label>
                            <input
                              type="number"
                              min="0"
                              max="100"
                              value={it.discount}
                              onChange={(e) => handleUpdateLineItem(idx, { discount: Number(e.target.value || 0) })}
                              className="w-full bg-white border border-slate-200 px-3 py-2 rounded-lg text-center"
                            />
                          </div>

                          <div>
                            <label className="block text-[10px] font-semibold text-slate-500 uppercase tracking-wider mb-1">Tax Percentage</label>
                            <select
                              value={it.taxPercentage}
                              onChange={(e) => handleUpdateLineItem(idx, { taxPercentage: Number(e.target.value) })}
                              className="w-full bg-white border border-slate-200 px-3 py-2 rounded-lg"
                            >
                              <option value="0">0%</option>
                              <option value="5">5%</option>
                              <option value="12">12%</option>
                              <option value="18">18%</option>
                              <option value="28">28%</option>
                            </select>
                          </div>
                        </div>

                        <div className="flex justify-between items-center pt-2.5 border-t border-slate-200">
                          <span className="text-xs text-slate-500 font-medium">Item Total:</span>
                          <span className="text-sm font-bold text-indigo-600">
                            {formatCurrency(it.total, currency)}
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Extra charge triggers with numeric configs */}
              <div className="space-y-2">
                <span className="text-xs font-semibold text-slate-500 uppercase tracking-wide">Additional Charges Module</span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {(formQuote.extraCharges || []).map(chg => (
                    <div key={chg.id} className="flex items-center justify-between p-3.5 rounded-xl border bg-slate-50/50">
                      <div className="flex items-center gap-2">
                        <input
                          type="checkbox"
                          checked={chg.isActive}
                          onChange={() => handleChargeToggle(chg.id)}
                        />
                        <span className="text-xs font-medium text-slate-700">{chg.name}</span>
                      </div>
                      <input
                        type="number"
                        disabled={!chg.isActive}
                        value={chg.amount}
                        onChange={(e) => handleChargeAmountChange(chg.id, Number(e.target.value || 0))}
                        className="w-24 bg-white border rounded px-2.5 py-1 text-xs text-right focus:outline-none"
                      />
                    </div>
                  ))}
                </div>
              </div>

              {/* Terms and notes area */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="col-span-2 sm:col-span-1">
                  <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">Appreciation Notes default</label>
                  <textarea
                    value={formQuote.notes}
                    onChange={(e) => handleFieldChange("notes", e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 h-20 resize-none text-xs focus:outline-none"
                  />
                </div>

                <div className="col-span-2 sm:col-span-1">
                  <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">T&C Legal Clauses</label>
                  <textarea
                    value={formQuote.terms}
                    onChange={(e) => handleFieldChange("terms", e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 h-20 resize-none text-xs focus:outline-none"
                  />
                </div>
              </div>

              {/* Template design selector */}
              <div>
                <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">Active Visual Template</label>
                <select
                  value={formQuote.templateId}
                  onChange={(e) => handleFieldChange("templateId", e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none"
                >
                  {templates.map(t => (
                    <option key={t.id} value={t.id}>{t.name}</option>
                  ))}
                </select>
              </div>

              {/* Final calculation row */}
              <div className="p-5 bg-slate-900 text-white rounded-xl space-y-3">
                <div className="flex justify-between items-center text-xs text-slate-400">
                  <span>Gross Subtotal</span>
                  <span>{formatCurrency(synchronizedFormQuote.subtotal, currency)}</span>
                </div>
                <div className="flex justify-between items-center text-xs text-slate-400">
                  <span>Gross Discount reductions</span>
                  <span>- {formatCurrency(synchronizedFormQuote.discountTotal, currency)}</span>
                </div>
                <div className="flex justify-between items-center text-xs text-slate-400">
                  <span>GST / Associated Taxes value</span>
                  <span>+ {formatCurrency(synchronizedFormQuote.taxTotal, currency)}</span>
                </div>
                {synchronizedFormQuote.chargesTotal > 0 && (
                  <div className="flex justify-between items-center text-xs text-slate-400">
                    <span>Selected Cargo Fees & Installation</span>
                    <span>+ {formatCurrency(synchronizedFormQuote.chargesTotal, currency)}</span>
                  </div>
                )}
                <div className="flex justify-between items-center border-t border-slate-800 pt-3 text-sm font-semibold">
                  <span className="text-cyan-400">Final Proposed Quote Total</span>
                  <span className="text-cyan-400 text-lg">{formatCurrency(synchronizedFormQuote.finalAmount, currency)}</span>
                </div>
                {/* Auto number to word display */}
                <span className="block text-[10px] text-slate-400 text-right italic pt-1.5">
                  In Words: {numberToWords(synchronizedFormQuote.finalAmount, currency)}
                </span>
              </div>

              <div className="flex gap-4 justify-end pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setActiveQuoteId(null)}
                  className="bg-slate-100 text-slate-600 px-4 py-2.5 rounded-lg text-xs font-semibold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleSaveQuotation}
                  className="bg-slate-900 hover:bg-slate-800 text-white font-semibold px-6 py-2.5 rounded-lg text-xs cursor-pointer shadow"
                >
                  Save Quotation Sheet
                </button>
              </div>
            </div>
          </div>

          {/* RIGHT LIVE PREVIEW & VISIBILITY SWEEP */}
          <div className="col-span-12 xl:col-span-5 space-y-6">
            <div className="bg-white border border-slate-150 rounded-xl shadow-xs p-6 space-y-4">
              <div className="flex justify-between items-center border-b pb-3">
                <h4 className="font-bold text-slate-800 text-sm flex items-center gap-1.5"><Monitor className="w-4 h-4 text-theme" /> Live Simulation Preview</h4>
                <div className="flex items-center gap-1.5 bg-slate-50 p-1.5 rounded-lg border">
                  {[
                    { id: "desktop", icon: Monitor, tooltip: "Desktop View" },
                    { id: "tablet", icon: Tablet, tooltip: "Tablet View" },
                    { id: "mobile", icon: Smartphone, tooltip: "Mobile View" },
                    { id: "print", icon: Printer, tooltip: "Print Layout" }
                  ].map(device => (
                    <button
                      key={device.id}
                      type="button"
                      onClick={() => setPreviewDevice(device.id as any)}
                      title={device.tooltip}
                      className={`p-1.5 rounded-md text-slate-500 cursor-pointer transition-colors ${previewDevice === device.id ? "bg-slate-900 text-white" : "hover:bg-slate-100"}`}
                    >
                      <device.icon className="w-3.5 h-3.5" />
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex gap-2 justify-between flex-wrap pb-2">
                <div className="flex items-center gap-2 flex-wrap">
                  <button
                    onClick={handleTriggerPrint}
                    type="button"
                    className="flex items-center gap-1.5 bg-slate-100 text-slate-700 hover:bg-slate-200 font-semibold text-[11px] px-3 py-2 rounded-lg cursor-pointer transition-colors"
                  >
                    <Printer className="w-3.5 h-3.5" /> Browser Print View
                  </button>
                  <button
                    onClick={handleDownloadPDF}
                    type="button"
                    disabled={isGeneratingPDF}
                    className={`flex items-center gap-1.5 bg-indigo-600 text-white hover:bg-indigo-700 font-semibold text-[11px] px-3 py-2 rounded-lg cursor-pointer shadow-xs transition-all ${
                      isGeneratingPDF ? "opacity-75 cursor-not-allowed" : ""
                    }`}
                  >
                    {isGeneratingPDF ? (
                      <>
                        <Loader2 className="w-3.5 h-3.5 animate-spin" /> Rendering PDF...
                      </>
                    ) : (
                      <>
                        <Download className="w-3.5 h-3.5" /> Export {getPaperParams(paperSize).label} PDF
                      </>
                    )}
                  </button>
                  
                  <select
                    value={paperSize}
                    onChange={(e) => setPaperSize(e.target.value as any)}
                    className="bg-white border border-slate-200 text-slate-650 text-[11px] rounded-lg px-2.5 py-2 font-semibold select-none cursor-pointer focus:outline-none focus:ring-1 focus:ring-indigo-500 hover:bg-slate-50 transition-colors"
                  >
                    <option value="a4">PDF Format: A4</option>
                    <option value="letter">PDF Format: US Letter</option>
                    <option value="legal">PDF Format: US Legal</option>
                  </select>
                </div>
              </div>

               {/* Styling & spacing fine tuning */}
               <div className="bg-slate-50 p-4 rounded-xl border border-slate-150 space-y-3.5">
                 <div className="flex items-center justify-between">
                   <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Sheet Layout Settings</span>
                 </div>
                 
                 <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                   <div className="flex items-center">
                     <label htmlFor="watermark-toggle" className="flex items-center gap-2 text-xs font-semibold text-slate-600 cursor-pointer select-none">
                       <input
                         type="checkbox"
                         id="watermark-toggle"
                         checked={formQuote.isWatermarked}
                         onChange={(e) => handleFieldChange("isWatermarked", e.target.checked)}
                         className="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500 h-4 w-4"
                       />
                       Show Status Watermark
                     </label>
                   </div>

                   <div className="flex flex-col gap-1">
                     <div className="flex justify-between items-center text-xs font-semibold text-slate-600">
                       <span>Row Spacing:</span>
                       <span className="bg-indigo-50 text-indigo-600 font-bold px-1.5 py-0.5 rounded text-[10px] font-mono">
                         {itemVerticalPadding}px
                       </span>
                     </div>
                     <div className="flex items-center gap-2 mt-0.5">
                       <span className="text-[9px] text-slate-400 font-medium select-none">Tight</span>
                       <input
                         type="range"
                         min="2"
                         max="18"
                         value={itemVerticalPadding}
                         onChange={(e) => setItemVerticalPadding(Number(e.target.value))}
                         className="w-full h-1 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-indigo-600 focus:outline-none"
                       />
                       <span className="text-[9px] text-slate-400 font-medium select-none">Wide</span>
                     </div>
                   </div>
                 </div>
               </div>

              {/* Responsive Container Box simulation */}
              <div className="bg-slate-100 p-4 rounded-xl flex justify-start md:justify-center border overflow-x-auto scrollbar-thin">
                <div
                  className="bg-white shadow-md transition-all text-sm relative"
                  style={{
                    width: previewDevice === "print" ? `${getPaperParams(paperSize).widthPx}px` : previewDevice === "desktop" ? "100%" : previewDevice === "tablet" ? "min(480px, 100%)" : "min(320px, 100%)",
                    minHeight: previewDevice === "print" ? `${getPaperParams(paperSize).heightPx * estimatedPages}px` : "auto",
                    padding: previewDevice === "print" ? "20mm" : "1.5rem",
                    fontFamily: activeTemplateRecord?.fontFamily === "JetBrains Mono" ? "monospace" : activeTemplateRecord?.fontFamily === "Playfair Display" ? "serif" : "sans-serif",
                    backgroundColor: activeTemplateRecord?.bgColor || "white",
                    borderColor: activeTemplateRecord?.accentColor || "#1e3a8a",
                    borderTopWidth: "6px"
                  }}
                  id="quotation-print-container"
                >
                  {/* Page break guidelines for Print mode simulation */}
                  {previewDevice === "print" && Array.from({ length: estimatedPages - 1 }).map((_, i) => {
                    const topPos = (i + 1) * getPaperParams(paperSize).heightPx;
                    return (
                      <div
                        key={i}
                        data-html2canvas-ignore="true"
                        className="absolute left-0 right-0 border-t-2 border-dashed border-rose-400 opacity-60 z-30 pointer-events-none flex items-center justify-center print:hidden text-center"
                        style={{ top: `${topPos}px` }}
                      >
                        <span className="bg-rose-50 text-rose-700 font-bold px-2 py-0.5 rounded text-[9px] uppercase tracking-wider absolute transform -translate-y-1/2 shadow-xs border border-rose-200">
                          {getPaperParams(paperSize).label} Page {i + 1} Limit
                        </span>
                      </div>
                    );
                  })}

                  {/* Watermark layer */}
                  {formQuote.isWatermarked && (
                    <div className="absolute inset-0 flex items-center justify-center opacity-10 pointer-events-none select-none z-0">
                      <span className="text-5xl font-extrabold uppercase border-4 border-slate-900 rounded-xl px-4 py-2 rotate-45 tracking-widest leading-none">
                        {formQuote.status}
                      </span>
                    </div>
                  )}

                  <div className="space-y-4 relative z-10 text-slate-800">
                    <div className="flex justify-between items-start gap-4 flex-wrap">
                      <div>
                        {activeCompanyRecord?.logoUrl && (
                          <img src={activeCompanyRecord.logoUrl} alt="Logo" className="w-10 h-10 object-cover rounded bg-slate-50 mb-1" referrerPolicy="no-referrer" />
                        )}
                        <h4 className="font-extrabold text-sm uppercase text-slate-900">{activeCompanyRecord?.name || "Corporate Enterprise Ltd"}</h4>
                        <p className="text-[10px] text-slate-500  max-w-xs">{activeCompanyRecord?.address}</p>
                        {visibleFields.gst && activeCompanyRecord?.gstin && <p className="text-[9px] text-slate-400 mt-1"><strong>GSTIN / Tax:</strong> {activeCompanyRecord.gstin}</p>}
                        {visibleFields.pan && activeCompanyRecord?.pan && <p className="text-[9px] text-slate-400"><strong>PAN:</strong> {activeCompanyRecord.pan}</p>}
                      </div>
                      <div className="text-right">
                        <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Project Proposal</span>
                        <h5 className="text-base font-bold text-slate-900 mt-1">{synchronizedFormQuote.quotationNumber}</h5>
                        <p className="text-[10px] text-slate-400 mt-1"><strong>Date:</strong> {synchronizedFormQuote.quotationDate}</p>
                        <p className="text-[10px] text-slate-400"><strong>Valid Until:</strong> {synchronizedFormQuote.validUntil}</p>
                      </div>
                    </div>

                    {/* Customer info card */}
                    <div className="p-3.5 bg-slate-50 rounded-lg space-y-1 text-xs border border-slate-100">
                      <span className="text-[9px] font-extrabold text-slate-400 uppercase tracking-wide">Quotation Proposed For:</span>
                      <h5 className="font-bold text-slate-900 text-xs">{activeCustomerRecord?.name || "Individual/Individual Vendor"}</h5>
                      {activeCustomerRecord?.companyName && <p className="text-[10px] text-indigo-700 font-semibold">{activeCustomerRecord.companyName}</p>}
                      <p className="text-[10px] text-slate-500 leading-tight">{activeCustomerRecord?.address}</p>
                      <p className="text-[10px] text-slate-400 pt-1"><strong>Mobile:</strong> {activeCustomerRecord?.mobile} &bull; <strong>Email:</strong> {activeCustomerRecord?.email}</p>
                    </div>

                    {/* Render spreadsheet list summary */}
                    <div className="overflow-x-auto">
                      <table className="w-full text-[10px] text-left border-collapse border-b border-slate-150">
                        <thead className="bg-[#f8fafc] text-slate-500 font-semibold uppercase">
                          <tr>
                            <th className="px-2 border-b" style={{ paddingTop: `${itemVerticalPadding}px`, paddingBottom: `${itemVerticalPadding}px` }}>Scope Item</th>
                            <th className="px-2 border-b w-10 text-center" style={{ paddingTop: `${itemVerticalPadding}px`, paddingBottom: `${itemVerticalPadding}px` }}>Qty</th>
                            <th className="px-2 border-b text-right" style={{ paddingTop: `${itemVerticalPadding}px`, paddingBottom: `${itemVerticalPadding}px` }}>Price</th>
                            {synchronizedFormQuote.taxTotal > 0 && <th className="px-2 border-b w-10 text-center" style={{ paddingTop: `${itemVerticalPadding}px`, paddingBottom: `${itemVerticalPadding}px` }}>GST%</th>}
                            <th className="px-2 border-b text-right w-20" style={{ paddingTop: `${itemVerticalPadding}px`, paddingBottom: `${itemVerticalPadding}px` }}>Total</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                          {(formQuote.items || []).map((it, idx) => (
                            <tr key={idx}>
                              <td className="px-2" style={{ paddingTop: `${itemVerticalPadding}px`, paddingBottom: `${itemVerticalPadding}px` }}>
                                <span className="font-bold block text-slate-900 text-[10px]">{it.name || "Default Line Product"}</span>
                                {it.description && <span className="text-[9px] text-slate-400 leading-tight block">{it.description}</span>}
                              </td>
                              <td className="px-2 text-center text-slate-500" style={{ paddingTop: `${itemVerticalPadding}px`, paddingBottom: `${itemVerticalPadding}px` }}>{it.quantity}</td>
                              <td className="px-2 text-right font-medium text-slate-600" style={{ paddingTop: `${itemVerticalPadding}px`, paddingBottom: `${itemVerticalPadding}px` }}>{formatCurrency(it.price, currency)}</td>
                              {synchronizedFormQuote.taxTotal > 0 && <td className="px-2 text-center text-slate-400" style={{ paddingTop: `${itemVerticalPadding}px`, paddingBottom: `${itemVerticalPadding}px` }}>{it.taxPercentage}%</td>}
                              <td className="px-2 text-right font-bold text-slate-900" style={{ paddingTop: `${itemVerticalPadding}px`, paddingBottom: `${itemVerticalPadding}px` }}>{formatCurrency(it.total, currency)}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>

                    {/* Meta totals list */}
                    <div className="space-y-1.5 text-[10px] text-right max-w-xs ml-auto">
                      <div className="flex justify-between items-center text-slate-500">
                        <span>Original Subtotal</span>
                        <span>{formatCurrency(synchronizedFormQuote.subtotal, currency)}</span>
                      </div>
                      {synchronizedFormQuote.discountTotal > 0 && (
                        <div className="flex justify-between items-center text-slate-400">
                          <span>Discount Reductions</span>
                          <span>- {formatCurrency(synchronizedFormQuote.discountTotal, currency)}</span>
                        </div>
                      )}
                      {visibleFields.taxBreakdown && synchronizedFormQuote.taxTotal > 0 && (
                        <div className="flex justify-between items-center text-slate-400">
                          <span>Accumulated CGST + SGST (18%)</span>
                          <span>+ {formatCurrency(synchronizedFormQuote.taxTotal, currency)}</span>
                        </div>
                      )}
                      {synchronizedFormQuote.chargesTotal > 0 && (
                        <div className="flex justify-between items-center text-slate-400">
                          <span>Catering Cargo & Handling</span>
                          <span>+ {formatCurrency(synchronizedFormQuote.chargesTotal, currency)}</span>
                        </div>
                      )}
                      <div className="flex justify-between items-center text-slate-950 font-bold border-t pt-1.5 text-xs">
                        <span>Grand proposed amount</span>
                        <span>{formatCurrency(synchronizedFormQuote.finalAmount, currency)}</span>
                      </div>
                    </div>

                    {/* Words */}
                    <p className="text-[9px] text-slate-400 text-right italic">
                      ({numberToWords(synchronizedFormQuote.finalAmount, currency)})
                    </p>

                    {/* QR Code and verification stamps */}
                    <div className="flex justify-between items-end pt-4 border-t border-slate-100 flex-wrap gap-4">
                      {/* UPI QR / Verification mock code */}
                      {visibleFields.upiQr && (
                        <div className="flex items-center gap-2">
                          <div className="w-12 h-12 border bg-slate-50 p-1 flex items-center justify-center shrink-0">
                            {/* Visual QR Simulator */}
                            <div className="w-full h-full bg-slate-200 flex flex-col gap-0.5 justify-center items-center rounded overflow-hidden">
                              <span className="text-[8px] font-extrabold text-slate-600 block">QR</span>
                              <span className="text-[6px] text-indigo-600 font-mono scale-90 block">UPILIVE</span>
                            </div>
                          </div>
                          <div>
                            <span className="text-[8px] text-slate-400 uppercase tracking-wide block">Verification URL / UPI</span>
                            <span className="text-[9px] font-bold text-slate-600 block">{activeCompanyRecord?.upiId || "upi://niswa@upi"}</span>
                            <span className="text-[7px] text-slate-400 block leading-none mt-0.5">&bull; Unified Payments Interface Stamped &bull;</span>
                          </div>
                        </div>
                      )}

                      {/* Signatures block */}
                      {visibleFields.signature && (
                        <div className="text-right">
                          <span className="text-[9px] text-slate-400 uppercase block tracking-wider mb-2">Authenticated Stamp Seal</span>
                          <span className="w-20 h-5 border-b border-dashed border-slate-300 block ml-auto" />
                          <span className="text-[9px] font-bold text-slate-900 block mt-1">{activeCompanyRecord?.name || "Authorised signatory"}</span>
                        </div>
                      )}
                    </div>

                    {/* Terms & notes custom visibility limits */}
                    {visibleFields.terms && formQuote.terms && (
                      <div className="pt-3 border-t border-slate-100 whitespace-pre-wrap text-[9px] text-slate-400 leading-normal font-mono">
                        <strong className="text-slate-500 font-sans text-[10px] block mb-1">CONTRACTUAL CLAUSES & ACCEPTANCE TERMS</strong>
                        {formQuote.terms}
                      </div>
                    )}

                    {visibleFields.notes && formQuote.notes && (
                      <div className="pt-2 text-[9px] text-slate-500 text-center leading-normal italic">
                        &quot;{formQuote.notes}&quot;
                      </div>
                    )}

                    {/* PDF page count visual indicator */}
                    <div
                      data-html2canvas-ignore="true"
                      className="mt-6 pt-3 border-t border-dashed border-slate-200 flex items-center justify-between text-[11px] text-slate-400 select-none print:hidden relative z-20"
                    >
                      <div className="flex items-center gap-1.5 font-semibold text-slate-500">
                        <FileText className="w-3.5 h-3.5 text-indigo-500" />
                        <span>Estimated PDF Pages:</span>
                        <span className="bg-indigo-50 text-indigo-600 font-bold px-1.5 py-0.5 rounded text-[10px] ml-0.5">
                          ~{estimatedPages} {estimatedPages === 1 ? "Page" : "Pages"}
                        </span>
                      </div>
                      <div className="text-[10px] text-slate-400 font-medium">
                        Format: <span className="font-semibold uppercase text-indigo-600">{getPaperParams(paperSize).label}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Dynamic Field Visibility Controls menu */}
              <div className="p-4 bg-slate-50 rounded-xl space-y-3.5 border text-xs">
                <span className="bg-white border rounded px-2.5 py-0.5 font-bold uppercase tracking-wider text-[10px]" id="indicator-parameters">Visible variables scheduler</span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                  {[
                    { label: "CGST/SGST details", key: "gst" },
                    { label: "PAN identification", key: "pan" },
                    { label: "Bank details block", key: "bankDetails" },
                    { label: "UPI and QR Stamp", key: "upiQr" },
                    { label: "Signatures line", key: "signature" },
                    { label: "Appreciation comment", key: "notes" },
                    { label: "Contractual clauses", key: "terms" },
                    { label: "Tax breakdown row", key: "taxBreakdown" }
                  ].map((field) => (
                    <label key={field.key} className="flex items-center gap-2 cursor-pointer font-medium text-slate-600">
                      <input
                        type="checkbox"
                        checked={(visibleFields as any)[field.key]}
                        onChange={() => setVisibleFields(prev => ({ ...prev, [field.key]: !(prev as any)[field.key] }))}
                      />
                      {field.label}
                    </label>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* QUICK INLINE DIALOGS OR WINDOW MODALS */}

      {/* 1. Add Company modal dialog */}
      {showCompanyModal && (
        <div className="fixed inset-0 bg-slate-950/40 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in text-sm">
          <div className="bg-white max-w-sm w-full p-6 rounded-2xl shadow-xl space-y-4">
            <h4 className="font-bold text-slate-950 text-base">Quick Add corporate profile</h4>
            <form onSubmit={handleAddCompanyInline} className="space-y-3">
              <div>
                <label className="text-xs font-semibold text-slate-500">Corporate Title *</label>
                <input
                  type="text"
                  required
                  value={newCompanyForm.name}
                  onChange={(e) => setNewCompanyForm({ ...newCompanyForm, name: e.target.value })}
                  className="w-full bg-slate-50 border rounded-lg px-2.5 py-1.5 focus:outline-none"
                  placeholder="e.g. Niswa Builders"
                />
              </div>
              <div>
                <label className="text-xs font-semibold text-slate-500">Contact Email *</label>
                <input
                  type="email"
                  required
                  value={newCompanyForm.email}
                  onChange={(e) => setNewCompanyForm({ ...newCompanyForm, email: e.target.value })}
                  className="w-full bg-slate-50 border rounded-lg px-2.5 py-1.5 focus:outline-none"
                />
              </div>
              <div>
                <label className="text-xs font-semibold text-slate-500">Mailing Office Address *</label>
                <input
                  type="text"
                  required
                  value={newCompanyForm.address}
                  onChange={(e) => setNewCompanyForm({ ...newCompanyForm, address: e.target.value })}
                  className="w-full bg-slate-50 border rounded-lg px-2.5 py-1.5 focus:outline-none"
                />
              </div>
              <div className="flex gap-2 pt-2 justify-end">
                <button
                  type="button"
                  onClick={() => setShowCompanyModal(false)}
                  className="bg-slate-100 text-slate-600 px-3 py-1.5 rounded-lg text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-slate-900 text-white px-4 py-1.5 rounded-lg text-xs font-bold"
                >
                  Quick Save
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 2. Add Customer modal dialog */}
      {showCustomerModal && (
        <div className="fixed inset-0 bg-slate-950/40 backdrop-blur-xs flex items-center justify-center p-4 z-50 text-sm">
          <div className="bg-white max-w-sm w-full p-6 rounded-2xl shadow-xl space-y-4">
            <h4 className="font-bold text-slate-900 text-base">Quick Register Client Card</h4>
            <form onSubmit={handleAddCustomerInline} className="space-y-3">
              <div>
                <label className="text-xs font-semibold text-slate-500">Client Contact Person Name *</label>
                <input
                  type="text"
                  required
                  value={newCustomerForm.name}
                  onChange={(e) => setNewCustomerForm({ ...newCustomerForm, name: e.target.value })}
                  className="w-full bg-slate-50 border rounded-lg px-2.5 py-1.5 focus:outline-none"
                  placeholder="e.g. Samuel Verma"
                />
              </div>
              <div>
                <label className="text-xs font-semibold text-slate-500">Email Address *</label>
                <input
                  type="email"
                  required
                  value={newCustomerForm.email}
                  onChange={(e) => setNewCustomerForm({ ...newCustomerForm, email: e.target.value })}
                  className="w-full bg-slate-50 border rounded-lg px-2.5 py-1.5 focus:outline-none"
                />
              </div>
              <div>
                <label className="text-xs font-semibold text-slate-500">Mobile Phone</label>
                <input
                  type="text"
                  required
                  value={newCustomerForm.mobile}
                  onChange={(e) => setNewCustomerForm({ ...newCustomerForm, mobile: e.target.value })}
                  className="w-full bg-slate-50 border rounded-lg px-2.5 py-1.5 focus:outline-none"
                />
              </div>
              <div className="flex gap-2 pt-2 justify-end">
                <button
                  type="button"
                  onClick={() => setShowCustomerModal(false)}
                  className="bg-slate-100 text-slate-600 px-3 py-1.5 rounded-lg text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-slate-900 text-white px-4 py-1.5 rounded-lg text-xs font-bold"
                >
                  Quick Save
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 3. GEMINI AI Smart Companion Dashboard */}
      {showAiAssistant && (
        <div className="fixed inset-0 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center p-4 z-50 text-sm animate-fade-in">
          <div className="bg-white max-w-lg w-full rounded-2xl shadow-2xl overflow-hidden border">
            {/* Header tab structure representation */}
            <div className="bg-slate-900 text-white p-5 flex justify-between items-center border-b border-slate-800">
              <span className="font-bold text-sm tracking-wide flex items-center gap-1.5">
                <Sparkles className="w-5 h-5 text-cyan-400" /> Google Gemini Quotation Specialist
              </span>
              <button
                onClick={() => setShowAiAssistant(false)}
                className="text-slate-400 text-xs hover:text-white"
              >
                Close Engine
              </button>
            </div>

            {/* Selector matrix tags */}
            <div className="flex bg-slate-100 border-b overflow-x-auto text-xs font-medium">
              {[
                { tab: "generator", label: "Prompt Creator" },
                { tab: "terms", label: "Clause Generator" },
                { tab: "parse", label: "OCR Card Parser" },
                { tab: "translate", label: "Convert Language" }
              ].map(item => (
                <button
                  key={item.tab}
                  onClick={() => setAiAssistantTab(item.tab as any)}
                  className={`px-4 py-3 shrink-0 cursor-pointer ${aiAssistantTab === item.tab ? "bg-white text-indigo-700 border-b-2 border-indigo-700" : "text-slate-500 hover:text-slate-800"}`}
                >
                  {item.label}
                </button>
              ))}
            </div>

            <div className="p-6 space-y-4">
              {aiAssistantTab === "generator" && (
                <div className="space-y-3">
                  <h4 className="font-semibold text-xs text-slate-700 uppercase tracking-wide">Write conversational quotation requests</h4>
                  <p className="text-xs text-slate-400 leading-normal">
                    Enter the project core, total pricing target or simple delivery items list. The AI will design custom pricing line-items, taxes, and legal scopes.
                  </p>
                  <textarea
                    value={aiMainPrompt}
                    onChange={(e) => setAiMainPrompt(e.target.value)}
                    placeholder='e.g., "Create a detailed quotation for school management software with a premium rate of ₹1,50,000, including training costs and server deployment"'
                    className="w-full bg-slate-50 border rounded-lg p-3 h-24 text-xs font-mono focus:outline-none"
                  />
                  <button
                    onClick={handleAiQuotationGen}
                    disabled={aiIsLoading || !aiMainPrompt}
                    className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2.5 rounded-lg text-xs flex justify-center items-center gap-1.5 disabled:opacity-50"
                  >
                    {aiIsLoading ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin" /> Designing Quote spreadsheet parameters...
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-4 h-4 text-cyan-300" /> Build Quote Items Automatically
                      </>
                    )}
                  </button>
                </div>
              )}

              {aiAssistantTab === "terms" && (
                <div className="space-y-4">
                  <div className="space-y-1">
                    <h4 className="font-semibold text-xs text-slate-700 uppercase tracking-wide">Industry specific T&C advisor</h4>
                    <p className="text-xs text-slate-400 leading-normal">Select an industry category to automate visual terms.</p>
                  </div>
                  <select
                    value={aiTermsIndustry}
                    onChange={(e) => setAiTermsIndustry(e.target.value)}
                    className="w-full bg-slate-50 border rounded-lg px-2.5 py-2.5 text-xs focus:outline-none"
                  >
                    <option value="IT">IT Infrastructure & Software Systems</option>
                    <option value="Construction">Building & Structural Civil Construction</option>
                    <option value="Catering">Events Management & Hospitality Catering</option>
                    <option value="Real Estate">Property Brokerage & Real Estate</option>
                    <option value="Educational">Schools/Colleges ERP Software integration</option>
                  </select>
                  <button
                    onClick={handleAiTermsGen}
                    disabled={aiIsLoading}
                    className="w-full bg-slate-900 hover:bg-slate-800 text-white font-bold py-2.5 rounded-lg text-xs"
                  >
                    Compile Clauses via Gemini
                  </button>
                </div>
              )}

              {aiAssistantTab === "parse" && (
                <div className="space-y-3">
                  <h4 className="font-semibold text-xs text-slate-700 uppercase tracking-wide">Extract RAW client signatures / addresses</h4>
                  <p className="text-xs text-slate-400 leading-normal">
                    Paste raw client contact, cards or emails info blocks below. Gemini extracts values, populates accounts structures and launches creation dialog.
                  </p>
                  <textarea
                    value={aiParseText}
                    onChange={(e) => setAiParseText(e.target.value)}
                    placeholder='Paste raw chunk: e.g. "Samuel Verma, Principal Architect, Acme Lab. GST: 27SAMP1001A. Samuel@acmelab.com 9991199911 Mumbai 400001"'
                    className="w-full bg-slate-50 border rounded-lg p-3 h-24 text-xs font-mono focus:outline-none"
                  />
                  <button
                    onClick={handleAiParserGen}
                    disabled={aiIsLoading || !aiParseText}
                    className="w-full bg-slate-900 border text-white font-bold py-2.5 rounded-lg text-xs"
                  >
                    Identify & Parse inline instantly
                  </button>
                </div>
              )}

              {aiAssistantTab === "translate" && (
                <div className="space-y-4">
                  <div className="space-y-1">
                    <h4 className="font-semibold text-xs text-slate-700 uppercase tracking-wide">Dynamic Translation Engine</h4>
                    <p className="text-xs text-slate-400 leading-normal">Translate the contractual terms and notes sections immediately maintaining numerical rates and codes.</p>
                  </div>
                  <select
                    value={aiTranslateLang}
                    onChange={(e) => setAiTranslateLang(e.target.value)}
                    className="w-full bg-slate-50 border rounded-lg px-3 py-2 text-xs focus:outline-none"
                  >
                    <option value="Hindi">Hindi (हिंदी)</option>
                    <option value="Telugu">Telugu (తెలుగు)</option>
                    <option value="Tamil">Tamil (தமிழ்)</option>
                    <option value="Kannada">Kannada (ಕನ್ನಡ)</option>
                    <option value="English">English</option>
                  </select>
                  <button
                    onClick={handleTranslateQuote}
                    disabled={aiIsLoading}
                    className="w-full bg-slate-900 text-white font-bold py-2.5 rounded-lg text-xs"
                  >
                    Convert Language Layout
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* 4. REVISIONS HISTORY SLIDER DRAWER SCREEN */}
      {showRevisionsId && (
        <div className="fixed inset-0 bg-slate-950/40 backdrop-blur-xs flex items-center justify-center p-4 z-50 text-sm">
          <div className="bg-white max-w-md w-full p-6 rounded-2xl shadow-xl space-y-4">
            <div className="flex justify-between items-center border-b pb-3">
              <h4 className="font-bold text-slate-900 text-base">Revision Audit Logs ({revisionsList.length})</h4>
              <button onClick={() => setShowRevisionsId(null)} className="text-slate-400 text-xs hover:text-slate-600">Close Logs</button>
            </div>
            <div className="space-y-2.5 max-h-80 overflow-y-auto">
              {revisionsList.length === 0 ? (
                <p className="text-center py-6 text-slate-400 text-xs font-semibold">No version updates recorded yet.</p>
              ) : (
                revisionsList.map((ver) => (
                  <div key={ver.id} className="p-3 bg-slate-50 rounded-lg hover:border-indigo-400 border transition flex items-center justify-between gap-3 text-xs">
                    <div>
                      <span className="font-extrabold text-indigo-700 block text-xs">Version state v{ver.version}</span>
                      <span className="text-[10px] text-slate-400 block">{new Date(ver.timestamp).toLocaleString()} &bull; by {ver.updatedBy}</span>
                      <span className="text-slate-500 font-medium block mt-1 text-[11px]">&quot;{ver.changes}&quot;</span>
                    </div>
                    <button
                      onClick={() => handleApplyVersionRollback(ver)}
                      className="bg-slate-900 text-white rounded px-2.5 py-1.5 font-bold hover:bg-slate-800 tracking-wide text-[10px]"
                    >
                      Restore State
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
