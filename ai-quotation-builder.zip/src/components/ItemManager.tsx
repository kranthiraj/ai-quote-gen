/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from "react";
import { Search, Plus, Trash2, Edit, CheckCircle, Database } from "lucide-react";
import { Item } from "../types";

interface ItemManagerProps {
  items: Item[];
  onAddItem: (item: Omit<Item, "id">) => void;
  onEditItem: (id: string, item: Partial<Item>) => void;
  onDeleteItem: (id: string) => void;
}

export default function ItemManager({ items, onAddItem, onEditItem, onDeleteItem }: ItemManagerProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [editingId, setEditingId] = useState<string | null>(null);
  const [isCreating, setIsCreating] = useState(false);

  const initialForm: Omit<Item, "id"> = {
    name: "",
    description: "",
    unit: "LS",
    hsnCode: "",
    sacCode: "",
    rate: 0,
    taxPercentage: 18
  };

  const [form, setForm] = useState(initialForm);

  // Filtering
  const filteredItems = useMemo(() => {
    return items.filter(val =>
      val.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (val.description && val.description.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (val.hsnCode && val.hsnCode.includes(searchTerm)) ||
      (val.sacCode && val.sacCode.includes(searchTerm))
    );
  }, [items, searchTerm]);

  const handleOpenEdit = (val: Item) => {
    setEditingId(val.id);
    setForm({
      name: val.name || "",
      description: val.description || "",
      unit: val.unit || "LS",
      hsnCode: val.hsnCode || "",
      sacCode: val.sacCode || "",
      rate: Number(val.rate || 0),
      taxPercentage: Number(val.taxPercentage || 18)
    });
    setIsCreating(false);
  };

  const handleOpenCreate = () => {
    setEditingId(null);
    setForm(initialForm);
    setIsCreating(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || form.rate === undefined) {
      alert("Name and standard rate values are required!");
      return;
    }

    if (editingId) {
      onEditItem(editingId, form);
      setEditingId(null);
    } else {
      onAddItem(form);
      setIsCreating(false);
    }
    setForm(initialForm);
  };

  return (
    <div className="space-y-6">
      {/* Search Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white p-5 rounded-xl border border-slate-100 shadow-xs">
        <div className="relative w-full sm:w-80">
          <Search className="w-5 h-5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search catalog item, HSN, or SAC code..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-slate-50 border border-slate-200 rounded-lg pl-10 pr-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>
        <button
          onClick={handleOpenCreate}
          className="flex items-center gap-2 bg-slate-900 text-white font-medium hover:bg-slate-800 active:scale-95 px-4 py-2.5 rounded-lg text-sm transition-transform cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          Add Catalog Item
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Table/List panel */}
        <div className={`col-span-12 ${isCreating || editingId ? "lg:col-span-6" : "lg:col-span-12"} space-y-4`}>
          <div className="bg-white rounded-xl border border-slate-100 shadow-xs divide-y divide-slate-100 overflow-hidden">
            {filteredItems.length === 0 ? (
              <div className="text-center py-12 text-sm text-slate-400 font-medium">
                No matching catalog items found in standard reusable repository.
              </div>
            ) : (
              filteredItems.map((val) => (
                <div key={val.id} className="p-4 flex flex-col sm:flex-row items-stretch sm:items-start justify-between gap-4 hover:bg-slate-50/50 transition-colors text-sm">
                  <div className="space-y-1">
                    <h4 className="font-semibold text-slate-900">{val.name}</h4>
                    {val.description && <p className="text-xs text-slate-500 max-w-md">{val.description}</p>}
                    <div className="flex flex-wrap items-center gap-x-4 gap-y-1 pt-1.5 text-xs text-slate-400 font-medium">
                      <span className="bg-slate-100 text-slate-700 px-2 py-0.5 rounded text-[10px] uppercase font-bold">{val.unit}</span>
                      <span><strong>Rate:</strong> ₹{val.rate.toLocaleString("en-IN")}</span>
                      <span><strong>GST / Tax:</strong> {val.taxPercentage}%</span>
                      {val.hsnCode && <span><strong>HSN:</strong> {val.hsnCode}</span>}
                      {val.sacCode && <span><strong>SAC:</strong> {val.sacCode}</span>}
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5 self-end sm:self-center shrink-0 border-t sm:border-t-0 border-slate-100/80 pt-2 sm:pt-0 justify-end w-full sm:w-auto">
                    <button
                      onClick={() => handleOpenEdit(val)}
                      className="p-1.5 text-slate-500 hover:text-slate-900 hover:bg-slate-50 rounded transition-colors cursor-pointer"
                    >
                      <Edit className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => {
                        if (confirm(`Remove ${val.name} from item templates?`)) onDeleteItem(val.id);
                      }}
                      className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded transition-colors cursor-pointer"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Input Block */}
        {(isCreating || editingId) && (
          <div className="col-span-12 lg:col-span-6 bg-white border border-slate-100 rounded-xl shadow-xs p-6 space-y-6">
            <h3 className="font-semibold text-slate-950 text-sm pb-3 border-b border-slate-100">
              {editingId ? "Edit Catalog Item Attributes" : "Register New Reusable Item"}
            </h3>

            <form onSubmit={handleSave} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="col-span-2">
                  <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">Item Name *</label>
                  <input
                    type="text"
                    required
                    value={form.name}
                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    placeholder="e.g. Custom Web Development"
                  />
                </div>

                <div className="col-span-2">
                  <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">Description</label>
                  <textarea
                    value={form.description}
                    onChange={(e) => setForm({ ...form, description: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-sm h-16 resize-none focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    placeholder="Technical deliverables or item details"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">Standard Rate (₹/Rate) *</label>
                  <input
                    type="number"
                    required
                    min="0"
                    value={form.rate}
                    onChange={(e) => setForm({ ...form, rate: Number(e.target.value) })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">Unit Metric</label>
                  <select
                    value={form.unit}
                    onChange={(e) => setForm({ ...form, unit: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none"
                  >
                    <option value="LS">LS (Lump sum)</option>
                    <option value="Bags">Bags</option>
                    <option value="Month">Month</option>
                    <option value="Pcs">Pcs</option>
                    <option value="Hrs">Hrs</option>
                    <option value="Service">Service</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">GST Rate / Tax (%)</label>
                  <select
                    value={form.taxPercentage}
                    onChange={(e) => setForm({ ...form, taxPercentage: Number(e.target.value) })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none"
                  >
                    <option value="0">0% (Nil)</option>
                    <option value="5">5% (GST)</option>
                    <option value="12">12% (GST)</option>
                    <option value="18">18% (GST)</option>
                    <option value="28">28% (GST)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">HSN Code (Goods)</label>
                  <input
                    type="text"
                    value={form.hsnCode}
                    onChange={(e) => setForm({ ...form, hsnCode: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-sm"
                    placeholder="e.g. 2523"
                  />
                </div>

                <div className="col-span-2">
                  <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">SAC Code (Services)</label>
                  <input
                    type="text"
                    value={form.sacCode}
                    onChange={(e) => setForm({ ...form, sacCode: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-sm"
                    placeholder="e.g. 998313"
                  />
                </div>
              </div>

              <div className="flex gap-3 justify-end pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => { setEditingId(null); setIsCreating(false); }}
                  className="bg-slate-100 text-slate-600 px-4 py-2 rounded-lg text-xs font-semibold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-slate-900 text-white hover:bg-slate-800 px-5 py-2 rounded-lg text-xs font-semibold cursor-pointer"
                >
                  Save Standard Catalog
                </button>
              </div>
            </form>
          </div>
        )}
      </div>
    </div>
  );
}
