/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { Settings, Shield, ToggleLeft, ToggleRight, Database, Lock, Save, Laptop, Languages, RefreshCw, Smartphone } from "lucide-react";
import { SystemSettings, AdminControls, UserRole } from "../types";

interface SystemSettingsManagerProps {
  settings: SystemSettings;
  adminControls: AdminControls;
  userRole: UserRole;
  onUpdateSettings: (data: { settings?: Partial<SystemSettings>; adminControls?: Partial<AdminControls>; userRole?: UserRole }) => void;
  onTriggerBackupRestore: (type: "backup" | "restore") => void;
}

export default function SystemSettingsManager({ settings, adminControls, userRole, onUpdateSettings, onTriggerBackupRestore }: SystemSettingsManagerProps) {
  const [localSettings, setLocalSettings] = useState<SystemSettings>({ ...settings });
  const [localControls, setLocalControls] = useState<AdminControls>({ ...adminControls });
  const [selectedRole, setSelectedRole] = useState<UserRole>(userRole);

  const handleSaveAll = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateSettings({
      settings: localSettings,
      adminControls: localControls,
      userRole: selectedRole
    });
    alert("Super Admin parameters updated successfully!");
  };

  const handleToggleControl = (key: keyof AdminControls) => {
    const updated = { ...localControls, [key]: !localControls[key] };
    setLocalControls(updated);
  };

  return (
    <form onSubmit={handleSaveAll} className="space-y-6">
      {/* Header action panel */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center bg-white p-5 rounded-xl border border-slate-100 shadow-xs gap-4">
        <div>
          <h2 className="text-lg font-bold text-slate-900 flex items-center gap-1.5"><Settings className="w-5 h-5 text-indigo-600" /> Settings & System Controls</h2>
          <p className="text-xs text-slate-500 mt-1">Configure default currencies, toggles AI features, backup tables and authenticate roles.</p>
        </div>
        <button
          type="submit"
          className="flex items-center gap-2 bg-slate-900 text-white font-medium hover:bg-slate-800 active:scale-95 px-6 py-2.5 rounded-lg text-xs tracking-wide transition-transform cursor-pointer"
        >
          <Save className="w-4 h-4" />
          Save System Setup
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column - General and Formats */}
        <div className="col-span-12 lg:col-span-7 space-y-6">
          <div className="bg-white rounded-xl border border-slate-100 p-6 shadow-xs space-y-6">
            <h3 className="font-semibold text-slate-800 text-sm pb-2 border-b border-slate-100 flex items-center gap-1.5">
              <Laptop className="w-4 h-4 text-emerald-600" /> Currency & Layout Defaults
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
              <div>
                <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">Primary Currency Symbol</label>
                <select
                  value={localSettings.currency}
                  onChange={(e) => setLocalSettings({ ...localSettings, currency: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none"
                >
                  <option value="₹">₹ (INR - Indian Rupee)</option>
                  <option value="$">$ (USD - US Dollars)</option>
                  <option value="€">€ (EUR - Euro)</option>
                  <option value="£">£ (GBP - British Pound)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">Standard Local Number Format</label>
                <select
                  value={localSettings.numberFormat}
                  onChange={(e) => setLocalSettings({ ...localSettings, numberFormat: e.target.value as any })}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none"
                >
                  <option value="Indian">Indian Lakes Format (e.g. 1,50,000.00)</option>
                  <option value="US">US Metric Format (e.g. 150,000.00)</option>
                  <option value="European">European dot Separation (e.g. 150.000,00)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">Quotation Date Format</label>
                <select
                  value={localSettings.dateFormat}
                  onChange={(e) => setLocalSettings({ ...localSettings, dateFormat: e.target.value as any })}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none"
                >
                  <option value="DD/MM/YYYY">DD/MM/YYYY (Standard Indian)</option>
                  <option value="YYYY-MM-DD">YYYY-MM-DD (ISO Format)</option>
                  <option value="MM/DD/YYYY">MM/DD/YYYY (USA format)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">Default Tax Bracket System</label>
                <select
                  value={localSettings.taxDefaultType}
                  onChange={(e) => setLocalSettings({ ...localSettings, taxDefaultType: e.target.value as any })}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none"
                >
                  <option value="No Tax">No Tax Structure</option>
                  <option value="GST">GST Global Structure (Itemised)</option>
                  <option value="CGST_SGST">Central CGST + SGST (Dual GST)</option>
                  <option value="IGST">Inter-state IGST System</option>
                  <option value="VAT">VAT Taxes System</option>
                  <option value="Custom">Custom Base Taxes</option>
                </select>
              </div>
            </div>
          </div>

          {/* Social template texts */}
          <div className="bg-white rounded-xl border border-slate-100 p-6 shadow-xs space-y-4">
            <h3 className="font-semibold text-slate-800 text-sm flex items-center gap-1.5">
              <Smartphone className="w-4 h-4 text-theme" /> Message Transmission Templates
            </h3>
            <p className="text-xs text-slate-400">Configure dynamic keys: <code>{`{customer_name}`}</code>, <code>{`{quote_number}`}</code>, <code>{`{final_amount}`}</code>, <code>{`{company_name}`}</code>, <code>{`{verification_url}`}</code> inside notifications.</p>

            <div className="space-y-4 text-sm">
              <div>
                <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">WhatsApp Standard text</label>
                <textarea
                  value={localSettings.whatsappMessageTemplate}
                  onChange={(e) => setLocalSettings({ ...localSettings, whatsappMessageTemplate: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs font-mono h-20 resize-none focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">Email Body script</label>
                <textarea
                  value={localSettings.emailMessageTemplate}
                  onChange={(e) => setLocalSettings({ ...localSettings, emailMessageTemplate: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs font-mono h-24 resize-none focus:outline-none"
                />
              </div>
            </div>
          </div>

          {/* Portable Backup-Restore box */}
          <div className="bg-white rounded-xl border border-slate-100 p-6 shadow-xs flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div className="space-y-1">
              <h4 className="font-semibold text-slate-800 text-sm flex items-center gap-1.5"><Database className="w-4 h-4 text-indigo-600" /> Database Backup Manager</h4>
              <p className="text-xs text-slate-400">Export standard SQL structured JSON or restore seed records.</p>
            </div>
            <div className="flex gap-2.5 shrink-0">
              <button
                type="button"
                onClick={() => onTriggerBackupRestore("backup")}
                className="bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold px-3 py-2 rounded-lg text-xs cursor-pointer"
              >
                Trigger Manual Backup
              </button>
            </div>
          </div>
        </div>

        {/* Right Column - Super Admin Controls & Roles */}
        <div className="col-span-12 lg:col-span-5 space-y-6">
          {/* User Role Switching Simulator */}
          <div className="bg-slate-900 text-white p-6 rounded-xl shadow-xs space-y-4 border border-slate-800">
            <h3 className="font-semibold text-xs uppercase tracking-wider text-slate-400 flex items-center gap-1.5"><Shield className="w-4 h-4 text-cyan-400" /> User Role Simulator</h3>
            <p className="text-xs text-slate-400">Simulate different workspace logins to evaluate responsive layout permission access.</p>

            <div className="space-y-2">
              {[
                { r: UserRole.SUPER_ADMIN, s: "Super Admin", desc: "Unrestricted master access for visual designs & toggles." },
                { r: UserRole.STAFF, s: "Staff User", desc: "Builds, sends & translates quotations." },
                { r: UserRole.READ_ONLY, s: "Read Only User", desc: "Can view metrics, previews & download. Edit controls locked." }
              ].map((roleRow) => (
                <label
                  key={roleRow.r}
                  onClick={() => setSelectedRole(roleRow.r)}
                  className={`w-full p-3 rounded-lg border flex items-start gap-3 transition-colors cursor-pointer text-xs ${
                    selectedRole === roleRow.r
                      ? "bg-slate-950 border-cyan-500 text-white"
                      : "bg-slate-950/40 border-slate-800 hover:bg-slate-950/60 text-slate-400"
                  }`}
                >
                  <input
                    type="radio"
                    name="role-switch"
                    checked={selectedRole === roleRow.r}
                    onChange={() => {}}
                    className="mt-0.5"
                  />
                  <div>
                    <span className="font-bold block text-[#fff]">{roleRow.s}</span>
                    <span className="text-[10px] text-slate-400 mt-0.5 block font-normal">{roleRow.desc}</span>
                  </div>
                </label>
              ))}
            </div>
          </div>

          {/* Super Admin toggles list */}
          <div className="bg-white rounded-xl border border-slate-100 p-6 shadow-xs space-y-5">
            <h3 className="font-semibold text-slate-800 text-sm pb-2 border-b border-slate-100 flex items-center gap-1.5">
              <Lock className="w-4 h-4 text-cyan-600" /> Super Admin Feature Switches
            </h3>

            <div className="space-y-4">
              {[
                { label: "Enable Gemini AI Assistant", key: "enableAiFeatures", desc: "Automate terms advisor, custom quotes generation." },
                { label: "Enable Ready Visual Templates", key: "enableTemplates", desc: "Render standard corporate visual structures." },
                { label: "Enable Tax and GST Calculation Module", key: "enableTaxModule", desc: "Automate item-wise tax CGST/SGST aggregates." },
                { label: "Enable Local Export Engine", key: "enableExportModule", desc: "Allow downloads of visual quotations." },
                { label: "Enable WhatsApp Delivery Integrations", key: "enableWhatsApp", desc: "Generate shareable quote triggers." },
                { label: "Enable Email Forward Deliveries", key: "enableEmail", desc: "Send summary quotes directly." },
                { label: "Enable AI Smart OCR PDF Import", key: "enableOCR", desc: "Parse raw invoice layouts to templates." },
                { label: "Enable Voice Quotation Builder", key: "enableVoiceInput", desc: "Allow microphone spoken requests processing." }
              ].map((row) => (
                <div key={row.key} className="flex justify-between items-start gap-4">
                  <div className="space-y-0.5">
                    <span className="text-xs font-semibold text-slate-800 block">{row.label}</span>
                    <span className="text-[10px] text-slate-400 block leading-tight">{row.desc}</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => handleToggleControl(row.key as keyof AdminControls)}
                    className="text-slate-400 hover:text-slate-900 transition-colors cursor-pointer shrink-0"
                  >
                    {localControls[row.key as keyof AdminControls] ? (
                      <ToggleRight className="w-9 h-9 text-indigo-500" />
                    ) : (
                      <ToggleLeft className="w-9 h-9 text-slate-300" />
                    )}
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </form>
  );
}
