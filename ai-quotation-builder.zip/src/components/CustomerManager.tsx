/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from "react";
import { Search, Plus, Trash2, Edit, UploadCloud, DownloadCloud, FileText, CheckCircle, HelpCircle } from "lucide-react";
import { Customer } from "../types";

interface CustomerManagerProps {
  customers: Customer[];
  onAddCustomer: (c: Omit<Customer, "id">) => void;
  onEditCustomer: (id: string, c: Partial<Customer>) => void;
  onDeleteCustomer: (id: string) => void;
  onImportCustomers: (list: any[]) => void;
}

export default function CustomerManager({ customers, onAddCustomer, onEditCustomer, onDeleteCustomer, onImportCustomers }: CustomerManagerProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [editingId, setEditingId] = useState<string | null>(null);
  const [isCreating, setIsCreating] = useState(false);
  const [showImportExport, setShowImportExport] = useState(false);
  
  // Custom states for JSON import paste
  const [pasteValue, setPasteValue] = useState("");
  const [errorMsg, setErrorMsg] = useState("");

  const initialForm: Omit<Customer, "id"> = {
    name: "",
    companyName: "",
    gstin: "",
    pan: "",
    address: "",
    mobile: "",
    email: "",
    state: "Delhi",
    country: "India"
  };

  const [form, setForm] = useState(initialForm);

  // Filtering
  const filteredCustomers = useMemo(() => {
    return customers.filter(c =>
      c.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (c.companyName && c.companyName.toLowerCase().includes(searchTerm.toLowerCase())) ||
      c.email.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [customers, searchTerm]);

  const handleOpenEdit = (c: Customer) => {
    setEditingId(c.id);
    setForm({
      name: c.name || "",
      companyName: c.companyName || "",
      gstin: c.gstin || "",
      pan: c.pan || "",
      address: c.address || "",
      mobile: c.mobile || "",
      email: c.email || "",
      state: c.state || "Delhi",
      country: c.country || "India"
    });
    setIsCreating(false);
  };

  const handleOpenCreate = () => {
    setEditingId(null);
    setForm(initialForm);
    setIsCreating(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.email || !form.mobile) {
      alert("Name, Email and Contact Number are required!");
      return;
    }

    if (editingId) {
      onEditCustomer(editingId, form);
      setEditingId(null);
    } else {
      onAddCustomer(form);
      setIsCreating(false);
    }
    setForm(initialForm);
  };

  // Perform import
  const handleImport = () => {
    try {
      setErrorMsg("");
      const list = JSON.parse(pasteValue);
      if (!Array.isArray(list)) {
        setErrorMsg("Input must be a valid JSON Array of objects.");
        return;
      }
      onImportCustomers(list);
      setPasteValue("");
      setShowImportExport(false);
      alert("Successfully imported " + list.length + " customers!");
    } catch (e: any) {
      setErrorMsg("Syntax Error: " + (e.message || "Invalid JSON syntax. Ensure keys and strings are double-quoted."));
    }
  };

  // Kopya full data
  const handleExport = () => {
    navigator.clipboard.writeText(JSON.stringify(customers, null, 2));
    alert("Copied entire Customer Database JSON array to clipboard!");
  };

  return (
    <div className="space-y-6">
      {/* Search Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white p-5 rounded-xl border border-slate-100 shadow-xs">
        <div className="relative w-full sm:w-80">
          <Search className="w-5 h-5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search customer, corporate, or email..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-slate-50 border border-slate-200 rounded-lg pl-10 pr-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={() => setShowImportExport(!showImportExport)}
            className="flex items-center gap-2 border border-slate-200 text-slate-700 bg-white hover:bg-slate-50 px-3.5 py-2.5 rounded-lg text-sm font-medium transition-colors cursor-pointer"
          >
            <UploadCloud className="w-4 h-4" />
            Import / Export
          </button>
          <button
            onClick={handleOpenCreate}
            className="flex items-center gap-2 bg-slate-900 text-white font-medium hover:bg-slate-800 active:scale-95 px-4 py-2.5 rounded-lg text-sm transition-transform cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            Add Customer
          </button>
        </div>
      </div>

      {/* JSON Import area */}
      {showImportExport && (
        <div className="bg-slate-900 text-white p-6 rounded-xl space-y-4">
          <div className="flex justify-between items-center border-b border-slate-800 pb-3">
            <h4 className="text-sm font-medium flex items-center gap-2"><HelpCircle className="w-4 h-4 text-cyan-400" /> Customer Batch Import / Export System</h4>
            <button onClick={() => setShowImportExport(false)} className="text-slate-400 text-xs hover:text-white">Close Utilities</button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <span className="text-xs font-semibold uppercase tracking-wider text-slate-400 block">Copy database record array</span>
              <p className="text-xs text-slate-400">Click to duplicate all existing customers in complete portable JSON array schema for migration backups.</p>
              <button
                onClick={handleExport}
                className="flex items-center gap-2 bg-slate-800 hover:bg-slate-700 font-medium px-4 py-2.5 rounded-lg text-xs transition-colors cursor-pointer"
              >
                <DownloadCloud className="w-3.5 h-3.5" />
                Copy Export JSON Array
              </button>
            </div>
            <div className="space-y-3">
              <span className="text-xs font-semibold uppercase tracking-wider text-slate-400 block">Paste Raw Customer list</span>
              <textarea
                value={pasteValue}
                onChange={(e) => setPasteValue(e.target.value)}
                placeholder='Paste raw JSON here: e.g. [{"name": "Rajesh Gupta", "email": "rajesh@gmail.com", "mobile": "9999111100", "address": "Delhi"}]'
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 h-24 text-xs font-mono text-cyan-400 placeholder-slate-600 focus:outline-none"
              />
              {errorMsg && <p className="text-rose-500 text-xs font-medium">{errorMsg}</p>}
              <button
                onClick={handleImport}
                className="bg-cyan-500 hover:bg-cyan-600 text-slate-950 font-semibold px-4 py-2 rounded-lg text-xs"
              >
                Validate & Trigger Import
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Grid listing */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className={`col-span-12 ${isCreating || editingId ? "lg:col-span-6" : "lg:col-span-12"} space-y-4`}>
          <div className="bg-white rounded-xl border border-slate-100 shadow-xs divide-y divide-slate-100 overflow-hidden text-sm">
            {filteredCustomers.length === 0 ? (
              <div className="text-center py-12 text-sm text-slate-400 font-medium">
                No matching customer registration cards found in the records.
              </div>
            ) : (
              filteredCustomers.map((c) => (
                <div key={c.id} className="p-4 flex flex-col sm:flex-row items-stretch sm:items-start justify-between gap-4 hover:bg-slate-50/50 transition-colors">
                  <div>
                    <h4 className="font-semibold text-slate-900 leading-tight">{c.name}</h4>
                    {c.companyName && <p className="text-xs font-medium text-indigo-600 mt-1">{c.companyName}</p>}
                    <p className="text-xs text-slate-500 mt-1 max-w-sm">{c.address}, {c.state}, {c.country}</p>
                    <div className="flex flex-wrap items-center gap-x-4 gap-y-1 mt-2 text-xs text-slate-400">
                      <span><strong>Tel:</strong> {c.mobile}</span>
                      <span>{c.email}</span>
                      {c.gstin && <span><strong>GST:</strong> {c.gstin}</span>}
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5 self-end sm:self-center shrink-0 border-t sm:border-t-0 border-slate-100/80 pt-2 sm:pt-0 justify-end w-full sm:w-auto">
                    <button
                      onClick={() => handleOpenEdit(c)}
                      className="p-2 text-slate-500 hover:text-slate-900 hover:bg-slate-55 rounded-lg transition-colors cursor-pointer"
                      title="Edit Customer"
                    >
                      <Edit className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => {
                        if (confirm(`Delete registry card for ${c.name}?`)) onDeleteCustomer(c.id);
                      }}
                      className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                      title="Delete profile"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Create/Edit dialog panel */}
        {(isCreating || editingId) && (
          <div className="col-span-12 lg:col-span-6 bg-white border border-slate-100 rounded-xl shadow-xs p-6 space-y-6">
            <div className="flex justify-between items-center pb-3 border-b border-slate-100">
              <h3 className="font-semibold text-slate-950 text-sm">
                {editingId ? "Edit Customer Registry" : "Register New Client"}
              </h3>
              <button
                onClick={() => { setEditingId(null); setIsCreating(false); }}
                className="text-xs text-slate-400 hover:text-slate-600 font-medium cursor-pointer"
              >
                Cancel
              </button>
            </div>

            <form onSubmit={handleSave} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="col-span-2">
                  <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">Contact Person Name *</label>
                  <input
                    type="text"
                    required
                    value={form.name}
                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    placeholder="e.g. Arjun Mehta"
                  />
                </div>

                <div className="col-span-2">
                  <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">Client Company Name</label>
                  <input
                    type="text"
                    value={form.companyName}
                    onChange={(e) => setForm({ ...form, companyName: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    placeholder="e.g. Acme Software Inc"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">GSTIN Code</label>
                  <input
                    type="text"
                    value={form.gstin}
                    onChange={(e) => setForm({ ...form, gstin: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    placeholder="e.g. 27AAAAA0000A1Z2"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">PAN Identification</label>
                  <input
                    type="text"
                    value={form.pan}
                    onChange={(e) => setForm({ ...form, pan: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    placeholder="e.g. ABCDE1234F"
                  />
                </div>

                <div className="col-span-2">
                  <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">Mailing / Billing Address</label>
                  <textarea
                    value={form.address}
                    onChange={(e) => setForm({ ...form, address: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-sm h-16 resize-none focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    placeholder="Billing street name and zip code"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">Mobile Contact *</label>
                  <input
                    type="text"
                    required
                    value={form.mobile}
                    onChange={(e) => setForm({ ...form, mobile: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">Email Address *</label>
                  <input
                    type="email"
                    required
                    value={form.email}
                    onChange={(e) => setForm({ ...form, email: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">State</label>
                  <input
                    type="text"
                    value={form.state}
                    onChange={(e) => setForm({ ...form, state: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">Country</label>
                  <input
                    type="text"
                    value={form.country}
                    onChange={(e) => setForm({ ...form, country: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-sm"
                  />
                </div>
              </div>

              <div className="flex gap-3 justify-end pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => { setEditingId(null); setIsCreating(false); }}
                  className="bg-slate-100 text-slate-600 px-4 py-2 rounded-lg text-xs font-semibold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-slate-900 text-white hover:bg-slate-800 px-5 py-2 rounded-lg text-xs font-semibold cursor-pointer"
                >
                  {editingId ? "Save Changes" : "Register Customer"}
                </button>
              </div>
            </form>
          </div>
        )}
      </div>
    </div>
  );
}
