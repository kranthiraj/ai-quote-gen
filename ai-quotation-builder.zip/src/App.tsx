/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { 
  Briefcase, Building2, Users, Database, Layout, Settings as SettingsIcon, 
  Sparkles, ShieldCheck, Download, UploadCloud, RefreshCw, Layers
} from "lucide-react";
import { Company, Customer, Item, Quotation, VisualTemplate, SystemSettings, AdminControls, UserRole } from "./types";
import DashboardView from "./components/DashboardView";
import CompanyManager from "./components/CompanyManager";
import CustomerManager from "./components/CustomerManager";
import ItemManager from "./components/ItemManager";
import TemplateBuilder from "./components/TemplateBuilder";
import SystemSettingsManager from "./components/SystemSettingsManager";
import QuotationWizard from "./components/QuotationWizard";

export default function App() {
  const [activeTab, setActiveTab] = useState<"dashboard" | "quotations" | "companies" | "customers" | "items" | "templates" | "settings">("dashboard");

  // Core databases
  const [companies, setCompanies] = useState<Company[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [items, setItems] = useState<Item[]>([]);
  const [quotations, setQuotations] = useState<Quotation[]>([]);
  const [templates, setTemplates] = useState<VisualTemplate[]>([]);
  const [settings, setSettings] = useState<SystemSettings>({
    currency: "₹",
    taxDefaultType: "GST",
    numberFormat: "Indian",
    dateFormat: "DD/MM/YYYY",
    whatsappMessageTemplate: "[Greetings], custom quotation QT-XXXX is issued. View details here: {verification_url}",
    emailMessageTemplate: "Dear [Name],\n\nWe have generated standard quotation details check out summary below.\n\nThanks,\nAdmin",
    emailHost: "",
    emailPort: 587,
    emailUsername: "",
    emailPassword: "",
    whatsappToken: "",
    whatsappPhoneId: "",
    aiDefaultModel: "gemini-1.5-flash",
    openaiKey: "",
    geminiKey: ""
  });
  const [adminControls, setAdminControls] = useState<AdminControls>({
    enableAiFeatures: true,
    enableTemplates: true,
    enableTaxModule: true,
    enableExportModule: true,
    enableWhatsApp: true,
    enableEmail: true,
    enableOCR: true,
    enableVoiceInput: true
  });
  const [userRole, setUserRole] = useState<UserRole>(UserRole.SUPER_ADMIN);

  const [isLoading, setIsLoading] = useState(true);

  // Load database seed on mount
  useEffect(() => {
    fetchDbState();
  }, []);

  const fetchDbState = async () => {
    try {
      setIsLoading(true);
      const res = await fetch("/api/db");
      const data = await res.json();
      if (data) {
        setCompanies(data.companies || []);
        setCustomers(data.customers || []);
        setItems(data.items || []);
        setQuotations(data.quotations || []);
        setTemplates(data.templates || []);
        if (data.settings) setSettings(data.settings);
        if (data.adminControls) setAdminControls(data.adminControls);
        if (data.userRole) setUserRole(data.userRole);
      }
    } catch (e) {
      console.error("Failed fetching database", e);
    } finally {
      setIsLoading(false);
    }
  };

  // Companies CRUD
  const handleAddCompany = async (form: Omit<Company, "id">) => {
    try {
      const res = await fetch("/api/companies", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form)
      });
      const added = await res.json();
      setCompanies(prev => [...prev, added]);
    } catch (e) {
      alert("Failed creating company");
    }
  };

  const handleEditCompany = async (id: string, form: Partial<Company>) => {
    try {
      const res = await fetch(`/api/companies/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form)
      });
      const updated = await res.json();
      setCompanies(prev => prev.map(c => c.id === id ? updated : c));
    } catch (e) {
      alert("Failed editing company");
    }
  };

  const handleDeleteCompany = async (id: string) => {
    try {
      await fetch(`/api/companies/${id}`, { method: "DELETE" });
      setCompanies(prev => prev.filter(c => c.id !== id));
    } catch (e) {
      alert("Failed deleting company");
    }
  };

  const handleCloneCompany = async (id: string) => {
    const parent = companies.find(c => c.id === id);
    if (!parent) return;
    await handleAddCompany({
      ...parent,
      name: `${parent.name} (Copy)`
    });
  };

  // Customers CRUD
  const handleAddCustomer = async (form: Omit<Customer, "id">) => {
    try {
      const res = await fetch("/api/customers", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form)
      });
      const added = await res.json();
      setCustomers(prev => [...prev, added]);
    } catch (e) {
      alert("Failed creating customer");
    }
  };

  const handleEditCustomer = async (id: string, form: Partial<Customer>) => {
    try {
      const res = await fetch(`/api/customers/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form)
      });
      const updated = await res.json();
      setCustomers(prev => prev.map(c => c.id === id ? updated : c));
    } catch (e) {
      alert("Failed editing customer");
    }
  };

  const handleDeleteCustomer = async (id: string) => {
    try {
      await fetch(`/api/customers/${id}`, { method: "DELETE" });
      setCustomers(prev => prev.filter(c => c.id !== id));
    } catch (e) {
      alert("Failed deleting customer");
    }
  };

  const handleBatchImportCustomers = async (list: any[]) => {
    try {
      for (const item of list) {
        await handleAddCustomer(item);
      }
      fetchDbState();
    } catch (e) {
      alert("Import transaction failed.");
    }
  };

  // Reusable Items CRUD
  const handleAddItem = async (form: Omit<Item, "id">) => {
    try {
      const res = await fetch("/api/items", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form)
      });
      const added = await res.json();
      setItems(prev => [...prev, added]);
    } catch (e) {
      alert("Failed saving catalog item");
    }
  };

  const handleEditItem = async (id: string, form: Partial<Item>) => {
    try {
      const res = await fetch(`/api/items/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form)
      });
      const updated = await res.json();
      setItems(prev => prev.map(i => i.id === id ? updated : i));
    } catch (e) {
      alert("Failed editing catalog item");
    }
  };

  const handleDeleteItem = async (id: string) => {
    try {
      await fetch(`/api/items/${id}`, { method: "DELETE" });
      setItems(prev => prev.filter(i => i.id !== id));
    } catch (e) {
      alert("Failed deleting catalog item");
    }
  };

  // Visual Templates Config
  const handleAddTemplate = async (form: Omit<VisualTemplate, "id" | "isCustom">) => {
    try {
      const res = await fetch("/api/templates", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form)
      });
      const added = await res.json();
      setTemplates(prev => [...prev, added]);
    } catch (e) {
      alert("Failed adding visual template config");
    }
  };

  const handleUpdateTemplate = async (id: string, form: Partial<VisualTemplate>) => {
    try {
      const res = await fetch(`/api/templates/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form)
      });
      const updated = await res.json();
      setTemplates(prev => prev.map(t => t.id === id ? { ...t, ...updated } : t));
    } catch (e) {
      alert("Failed updating visual template configurations");
    }
  };

  // Quotations Master CRUD
  const handleAddQuotation = async (form: Omit<Quotation, "id" | "version">) => {
    try {
      const res = await fetch("/api/quotations", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form)
      });
      const added = await res.json();
      setQuotations(prev => [...prev, added]);
    } catch (e) {
      alert("Failed creating quotation sheet");
    }
  };

  const handleUpdateQuotation = async (id: string, form: Partial<Quotation> & { revisionComment?: string }) => {
    try {
      const res = await fetch(`/api/quotations/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form)
      });
      const updated = await res.json();
      setQuotations(prev => prev.map(q => q.id === id ? updated : q));
    } catch (e) {
      alert("Failed editing quotation fields");
    }
  };

  const handleDeleteQuotation = async (id: string) => {
    try {
      await fetch(`/api/quotations/${id}`, { method: "DELETE" });
      setQuotations(prev => prev.filter(q => q.id !== id));
    } catch (e) {
      alert("Failed deleting quotation sheet");
    }
  };

  const handleDuplicateQuotation = async (id: string) => {
    try {
      const parent = quotations.find(q => q.id === id);
      if (!parent) return;
      await handleAddQuotation({
        ...parent,
        quotationNumber: `${parent.quotationNumber}-copy`,
        status: "Draft",
        isWatermarked: false
      } as any);
      alert("Duplicated quotation as Draft sheet!");
    } catch (e) {
      alert("Copy transaction failed.");
    }
  };

  const handleUpdateSettings = async (payload: { settings?: Partial<SystemSettings>; adminControls?: Partial<AdminControls>; userRole?: UserRole }) => {
    try {
      const res = await fetch("/api/settings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      if (data) {
        if (data.settings) setSettings(data.settings);
        if (data.adminControls) setAdminControls(data.adminControls);
        if (data.userRole) setUserRole(data.userRole);
      }
    } catch (e) {
      alert("Failed updating system settings");
    }
  };

  // Backups
  const handleTriggerBackupRestore = async (type: "backup" | "restore") => {
    if (type === "backup") {
      const res = await fetch("/api/db/backup");
      const text = await res.text();
      // Fast download triggers directly
      const blob = new Blob([text], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `quotation_platform_backup_${Date.now()}.json`;
      a.click();
      alert("Database backup JSON downloaded successfully!");
    }
  };

  return (
    <div className="min-h-screen bg-[#fafafa] text-slate-800 flex flex-col font-sans">
      {/* Dynamic Security Indicator Banner */}
      <div className="bg-slate-900 text-white px-4 sm:px-6 py-2 sm:py-2.5 flex flex-col sm:flex-row items-start sm:items-center justify-between text-[10px] sm:text-xs font-semibold tracking-wide border-b border-slate-800 shrink-0 gap-2">
        <div className="flex items-center gap-2">
          <ShieldCheck className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-emerald-400 shrink-0" />
          <span className="truncate">Multi-Tenant Enterprise Portal Active &bull; Secure sandbox logs</span>
        </div>
        <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
          <span>Active Persona: <strong className="text-cyan-400">{userRole}</strong></span>
          <span className="text-slate-400">Currency: <strong className="text-white">{settings.currency}</strong></span>
        </div>
      </div>

      {/* Main Top Header Navigation */}
      <header className="bg-white border-b border-slate-100 py-3 sm:py-4 px-4 sm:px-6 shadow-xs flex flex-col md:flex-row justify-between items-start md:items-center gap-4 shrink-0">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 sm:w-10 sm:h-10 bg-indigo-600 rounded-lg sm:rounded-xl flex items-center justify-center text-white font-extrabold shadow-sm text-sm sm:text-base">
            N
          </div>
          <div>
            <h1 className="text-sm sm:text-base font-bold text-slate-950 tracking-tight leading-tight">Niswa Quotation Workspace</h1>
            <p className="text-[10px] sm:text-[11px] text-slate-400 font-medium">Precision AI Quotation & Template Engine</p>
          </div>
        </div>

        {/* Modular Navigation switches - Scrollable on mobile */}
        <div className="w-full md:w-auto overflow-x-auto scrollbar-none -mx-4 px-4 md:mx-0 md:px-0">
          <nav className="flex flex-nowrap md:flex-wrap items-center gap-1 bg-slate-50 border p-1 rounded-xl text-xs font-semibold w-max md:w-auto">
            {[
              { id: "dashboard", label: "Dashboard", icon: Layers },
              { id: "quotations", label: "Quotations", icon: Briefcase },
              { id: "companies", label: "Companies", icon: Building2 },
              { id: "customers", label: "Customers", icon: Users },
              { id: "items", label: "Item Catalog", icon: Database },
              { id: "templates", label: "Templates", icon: Layout },
              { id: "settings", label: "Settings", icon: SettingsIcon }
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-1.5 px-3 py-1.5 sm:px-3.5 sm:py-2 rounded-lg transition-colors cursor-pointer select-none whitespace-nowrap ${
                  activeTab === tab.id
                    ? "bg-slate-900 border-slate-900 text-white shadow-xs"
                    : "text-slate-500 hover:text-slate-800 hover:bg-slate-100"
                }`}
              >
                <tab.icon className="w-3.5 h-3.5" />
                {tab.label}
              </button>
            ))}
          </nav>
        </div>
      </header>

      {/* Primary Work area container */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 overflow-x-hidden overflow-y-auto">
        {isLoading ? (
          <div className="flex flex-col items-center justify-center h-96 gap-3">
            <RefreshCw className="w-8 h-8 text-indigo-600 animate-spin" />
            <p className="text-sm text-slate-400 font-medium">Verifying tenant databases configurations...</p>
          </div>
        ) : (
          <div className="animate-fade-in">
            {activeTab === "dashboard" && (
              <DashboardView
                quotations={quotations}
                companies={companies}
                customers={customers}
                onNavigate={(t: any) => setActiveTab(t)}
                currency={settings.currency}
              />
            )}

            {activeTab === "companies" && (
              <CompanyManager
                companies={companies}
                onAddCompany={handleAddCompany}
                onEditCompany={handleEditCompany}
                onDeleteCompany={handleDeleteCompany}
                onCloneCompany={handleCloneCompany}
              />
            )}

            {activeTab === "customers" && (
              <CustomerManager
                customers={customers}
                onAddCustomer={handleAddCustomer}
                onEditCustomer={handleEditCustomer}
                onDeleteCustomer={handleDeleteCustomer}
                onImportCustomers={handleBatchImportCustomers}
              />
            )}

            {activeTab === "items" && (
              <ItemManager
                items={items}
                onAddItem={handleAddItem}
                onEditItem={handleEditItem}
                onDeleteItem={handleDeleteItem}
              />
            )}

            {activeTab === "templates" && (
              <TemplateBuilder
                templates={templates}
                onAddTemplate={handleAddTemplate}
                onUpdateTemplate={handleUpdateTemplate}
              />
            )}

            {activeTab === "settings" && (
              <SystemSettingsManager
                settings={settings}
                adminControls={adminControls}
                userRole={userRole}
                onUpdateSettings={handleUpdateSettings}
                onTriggerBackupRestore={handleTriggerBackupRestore}
              />
            )}

            {activeTab === "quotations" && (
              <QuotationWizard
                quotations={quotations}
                companies={companies}
                customers={customers}
                itemsDatabase={items}
                templates={templates}
                userRole={userRole}
                currency={settings.currency}
                enableAi={adminControls.enableAiFeatures}
                onAddQuotation={handleAddQuotation}
                onUpdateQuotation={handleUpdateQuotation}
                onDeleteQuotation={handleDeleteQuotation}
                onDuplicateQuotation={handleDuplicateQuotation}
                onAddCompany={handleAddCompany}
                onAddCustomer={handleAddCustomer}
              />
            )}
          </div>
        )}
      </main>

      {/* Flat Footer */}
      <footer className="bg-white border-t border-slate-100 py-3 px-6 shrink-0 text-center text-[10px] text-slate-400 font-medium">
        &copy; 2026 Niswa. Built with architectural honesty. Powered by Google Gemini AI. All Rights Reserved.
      </footer>
    </div>
  );
}
